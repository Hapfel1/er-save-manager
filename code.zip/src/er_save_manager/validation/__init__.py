"""ER Save Manager - Validation Module."""
