"""Platform-specific utilities for cross-platform support."""

from .utils import PlatformUtils

__all__ = ["PlatformUtils"]
