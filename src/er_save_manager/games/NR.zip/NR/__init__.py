"""Nightreign game module."""
