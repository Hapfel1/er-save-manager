"""
Main GUI Application
Modular Elden Ring Save Manager GUI
"""

import os
import subprocess
import sys
import threading
import tkinter as tk
from importlib import resources
from pathlib import Path
from tkinter import filedialog, ttk

import customtkinter as ctk

from er_save_manager import VersionChecker, __version__
from er_save_manager.games.game_profiles import GAME_PROFILES, PROFILES_BY_KEY
from er_save_manager.parser import Save
from er_save_manager.platform import PlatformUtils

# Import all modular components
from er_save_manager.ui.dialogs.character_details import CharacterDetailsDialog
from er_save_manager.ui.dialogs.save_selector import SaveSelectorDialog
from er_save_manager.ui.editors import (
    CharacterInfoEditor,
    EquipmentEditor,
    InventoryEditor,
    StatsEditor,
)
from er_save_manager.ui.messagebox import CTkMessageBox
from er_save_manager.ui.settings import get_settings
from er_save_manager.ui.tabs import (
    AdvancedToolsTab,
    AppearanceTab,
    BackupManagerTab,
    CharacterManagementTab,
    EventFlagsTab,
    GesturesRegionsTab,
    HexEditorTab,
    SaveInspectorTab,
    SettingsTab,
    SteamIDPatcherTab,
    WorldStateTab,
)
from er_save_manager.ui.theme import ThemeManager
from er_save_manager.ui.utils import open_url, trace_variable


class SaveManagerGUI:
    """Main GUI application for Elden Ring Save Manager"""

    def __init__(self, root):
        self.root = root
        self.root.title("Elden Ring Save Manager")
        self.root.geometry("1200x1000")
        self.root.minsize(800, 700)

        # Set application icon
        try:
            # Detect if running as frozen/packaged executable
            if getattr(sys, "frozen", False):
                # Running as compiled executable
                if hasattr(sys, "_MEIPASS"):
                    # PyInstaller (Linux)
                    base_path = Path(sys._MEIPASS)
                else:
                    # cx_Freeze (Windows)
                    base_path = Path(sys.executable).parent
            else:
                # Running as script
                base_path = Path(__file__).parent.parent.parent

            icon_path = base_path / "resources" / "icon" / "icon.ico"
            if icon_path.exists():
                self.root.iconbitmap(str(icon_path))
            else:
                # Fallback to PNG if ICO doesn't exist
                icon_png = base_path / "resources" / "icon" / "icon.png"
                if icon_png.exists():
                    from PIL import Image, ImageTk

                    icon_image = Image.open(icon_png)
                    icon_photo = ImageTk.PhotoImage(icon_image)
                    self.root.iconphoto(True, icon_photo)
        except Exception:
            pass

        # Initialize settings
        self.settings = get_settings()

        # Configure customtkinter appearance based on saved theme (default to dark)
        theme_name = self.settings.get("theme", None)
        if theme_name is None or theme_name == "dark":
            ctk.set_appearance_mode("dark")
            theme_name = "dark"
        elif theme_name == "bright" or theme_name == "default":
            ctk.set_appearance_mode("light")
            theme_name = "bright"

        # Try to load lavender theme from customtkinterthemes
        try:
            import customtkinterthemes as ctt

            theme_path = resources.files(ctt).joinpath("Themes", "lavender.json")
            ctk.set_default_color_theme(theme_path)
        except Exception:
            ctk.set_default_color_theme("dark-blue")

        # Initialize theme manager for any remaining ttk widgets (during migration)
        self.theme_manager = ThemeManager(theme_name)

        # Configure style for legacy ttk widgets
        style = ttk.Style()
        style.theme_use("clam")
        self.theme_manager.apply_theme(style)

        # Configure background for root window
        self.root.configure(bg=self.theme_manager.get_color("bg"))

        # State
        self.default_save_path = Path(os.environ.get("APPDATA", "")) / "EldenRing"
        self.save_file = None
        self.save_path = None
        self.selected_slot = None
        self.selected_slot_index = -1  # Current selected character slot (0-9)

        # Active game (key from game_profiles.py); drives which tabs are shown
        self.active_game = "elden_ring"

        # DSR-specific parsed save (separate from ER save_file)
        self.dsr_save = None
        # DS3-specific parsed save
        self.ds3_save = None
        self._file_load_buttons: list = []

        # Lazy loading flags (track which tabs have been initialized with data)
        self.tabs_loaded = {
            "Save Fixer": False,
            "Appearance": False,
            "Advanced Tools": False,
            "SteamID Patcher": False,
            "Hex Editor": False,
            "Gestures": False,
        }

        # Status
        self.status_var = tk.StringVar(value="Ready")

        # Resize debouncing for performance
        self._resize_timer = None
        self._last_width = None
        self._last_height = None

        # Auto-backup process monitor
        self.process_monitor = None

        # External file modification watcher
        self._watched_mtime: float | None = None
        self._file_change_dialog_open: bool = False
        self._file_watcher_running: bool = False
        self._pending_file_change: bool = False

        self.setup_ui()

        # Apply theme colors to tk widgets (non-ttk)
        self.theme_manager.apply_tk_widget_colors(self.root)

        # Bind resize event with debouncing
        self.root.bind("<Configure>", self._on_window_resize)

        # Show external-modification dialog when the user refocuses the window
        self.root.bind("<FocusIn>", self._on_window_focus)

        # Start auto-backup process monitor
        self.root.after(2000, self._init_process_monitor)

        # Check for updates asynchronously (don't block UI startup)
        self.root.after(1000, self._check_for_updates)

    def _on_window_resize(self, event=None):
        """Debounce window resize events to improve responsiveness"""
        if event is None:
            return

        # Only process if size actually changed (skip if just movement)
        width = event.width
        height = event.height

        if width == self._last_width and height == self._last_height:
            return

        self._last_width = width
        self._last_height = height

        # Cancel pending resize processing
        if self._resize_timer:
            self.root.after_cancel(self._resize_timer)

        # Delay actual processing to batch multiple resize events
        self._resize_timer = self.root.after(200, self._process_resize)

    def _process_resize(self):
        """Process pending resize -- CTk handles its own layout."""
        self._resize_timer = None

    def _check_for_updates(self):
        """Check for application updates in a background thread"""

        def check_in_thread():
            try:
                # Check if user wants to see update notifications
                if not self.settings.get("show_update_notifications", True):
                    return

                checker = VersionChecker(__version__)
                has_update, latest_version, download_url = checker.check_for_updates()

                if has_update and latest_version and download_url:
                    # Schedule the dialog to show on the main thread
                    self.root.after(
                        0,
                        lambda: self._show_update_dialog(latest_version, download_url),
                    )

            except Exception as e:
                # Silently fail on update check errors
                print(f"Update check failed: {e}")

        # Run check in background thread
        import threading

        thread = threading.Thread(target=check_in_thread, daemon=True)
        thread.start()

    def _handle_game_running_dialog(self, profile=None) -> bool:
        """
        Show dialog when game is running and handle user choice.
        Blocks loading until game process is terminated.

        Returns:
            True if game was successfully terminated
            False if user cancelled or kill failed
        """
        game_name = profile.name if profile else "Elden Ring"
        process_name = (
            profile.process_name
            if profile and profile.process_name
            else "eldenring.exe"
        )

        result = CTkMessageBox.askyesno(
            "Game is Running",
            f"{game_name} is currently running.\n\n"
            "The save file cannot be loaded while the game is running.\n\n"
            "Would you like to force kill the game process?",
            parent=self.root,
        )

        if not result:
            return False

        if not PlatformUtils.kill_game_process():
            CTkMessageBox.showerror(
                "Error",
                f"Failed to terminate {game_name} process.\n\n"
                "The game may require manual closing or administrator permissions.",
                parent=self.root,
            )
            return False

        import time

        max_wait = 5
        wait_interval = 0.2
        elapsed = 0

        while elapsed < max_wait:
            if not self.is_game_running(process_name):
                CTkMessageBox.showinfo(
                    "Success",
                    f"{game_name} process terminated successfully.\n\n"
                    "You can now proceed safely.",
                    parent=self.root,
                )
                return True
            time.sleep(wait_interval)
            elapsed += wait_interval
            self.root.update()

        CTkMessageBox.showerror(
            "Timeout",
            f"Game process is still running after kill attempt.\n\n"
            f"Please close {game_name} manually and try again.",
            parent=self.root,
        )
        return False

    def _init_process_monitor(self):
        """Initialize auto-backup process monitor"""
        try:
            from er_save_manager.backup.process_monitor import GameProcessMonitor

            # Start process monitor (first-run dialog moved to backup manager tab)
            self.process_monitor = GameProcessMonitor()
            self.process_monitor.set_backup_callback(self._on_auto_backup_created)
            self.process_monitor.start()

        except Exception as e:
            print(f"Failed to initialize process monitor: {e}")

    def _on_auto_backup_created(self, game_key: str, backup_path):
        """Callback when auto-backup is created."""
        try:
            from er_save_manager.games.game_profiles import PROFILES_BY_KEY
            from er_save_manager.ui.messagebox import CTkMessageBox

            profile = PROFILES_BY_KEY.get(game_key)
            game_name = profile.name if profile else game_key

            self.root.after(
                0,
                lambda: CTkMessageBox.showinfo(
                    "Auto-Backup Created",
                    f"{game_name} launched - backup created:\n\n{backup_path.name}",
                    parent=self.root,
                ),
            )
        except Exception:
            pass

    def show_toast(self, message: str, duration: int = 3000, type: str = "success"):
        """Show toast notification"""
        from er_save_manager.ui.toast import show_toast as _show_toast

        _show_toast(self.root, message, duration, type)

    def _show_update_dialog(self, latest_version: str, download_url: str):
        """Show update available dialog with GitHub and Nexus Mods download options"""
        from er_save_manager.ui.utils import force_render_dialog

        dialog = ctk.CTkToplevel(self.root)
        dialog.title("Update Available")
        dialog.geometry("550x320")
        dialog.transient(self.root)

        force_render_dialog(dialog)

        # Center dialog over parent window
        dialog.update_idletasks()
        parent_x = self.root.winfo_x()
        parent_y = self.root.winfo_y()
        parent_width = self.root.winfo_width()
        parent_height = self.root.winfo_height()

        dialog_width = 550
        dialog_height = 320

        x = parent_x + (parent_width - dialog_width) // 2
        y = parent_y + (parent_height - dialog_height) // 2

        dialog.geometry(f"{dialog_width}x{dialog_height}+{x}+{y}")

        dialog.grab_set()

        main_frame = ctk.CTkFrame(dialog)
        main_frame.pack(fill=ctk.BOTH, expand=True, padx=20, pady=20)

        # Title
        ctk.CTkLabel(
            main_frame,
            text="🎉 Update Available!",
            font=("Segoe UI", 16, "bold"),
        ).pack(pady=(0, 15))

        # Version info
        info_text = (
            f"A new version of ER Save Manager is available!\n\n"
            f"Current version: {__version__}\n"
            f"Latest version: {latest_version}"
        )
        ctk.CTkLabel(
            main_frame,
            text=info_text,
            font=("Segoe UI", 11),
            justify=ctk.LEFT,
        ).pack(pady=(0, 20))

        # Download options label
        ctk.CTkLabel(
            main_frame,
            text="Download from:",
            font=("Segoe UI", 12, "bold"),
        ).pack(anchor=ctk.W, pady=(0, 10))

        # Download buttons
        button_frame = ctk.CTkFrame(main_frame, fg_color="transparent")
        button_frame.pack(fill=ctk.X, pady=(0, 20))

        def open_github():
            open_url(download_url)
            dialog.destroy()

        def open_nexus():
            open_url("https://www.nexusmods.com/eldenring/mods/9271?tab=files")
            dialog.destroy()

        ctk.CTkButton(
            button_frame,
            text="📦 GitHub Releases",
            command=open_github,
            width=240,
            height=40,
        ).pack(side=ctk.LEFT, padx=(0, 10))

        ctk.CTkButton(
            button_frame,
            text="🔗 Nexus Mods",
            command=open_nexus,
            width=240,
            height=40,
        ).pack(side=ctk.LEFT)

        # Don't show again checkbox
        dont_show_var = ctk.BooleanVar(value=False)
        checkbox = ctk.CTkCheckBox(
            main_frame,
            text="Don't show update notifications in the future",
            variable=dont_show_var,
            font=("Segoe UI", 10),
        )
        checkbox.pack(anchor=ctk.W, pady=(0, 15))

        # Close button
        def on_close():
            if dont_show_var.get():
                self.settings.set("show_update_notifications", False)
            dialog.destroy()

        ctk.CTkButton(
            main_frame,
            text="Close",
            command=on_close,
            width=120,
            height=32,
        ).pack(pady=(5, 0))

    def _open_kofi(self):
        """Open Ko-fi support page in browser."""
        open_url("https://ko-fi.com/hapfell")

    def _open_discord(self):
        """Open Discord server invite in browser."""
        open_url("https://dsc.gg/er-saveman")

    def setup_ui(self):
        """Setup main UI structure with optimized layout"""
        # Use grid for main container - more efficient than pack
        self.root.grid_rowconfigure(0, weight=0)  # Title
        self.root.grid_rowconfigure(1, weight=0)  # File selection
        self.root.grid_rowconfigure(2, weight=1)  # Main content (tabs)
        self.root.grid_rowconfigure(3, weight=0)  # Status bar
        self.root.grid_columnconfigure(0, weight=1)

        # Title
        title_frame = ctk.CTkFrame(self.root, corner_radius=12)
        title_frame.grid(row=0, column=0, padx=12, pady=(12, 6), sticky="ew")

        # Support button (top right corner)
        support_btn = ctk.CTkButton(
            title_frame,
            text="☕ Support me",
            command=self._open_kofi,
            width=100,
            height=32,
            font=("Segoe UI", 11),
        )
        support_btn.place(relx=1.0, x=-12, y=12, anchor="ne")

        discord_btn = ctk.CTkButton(
            title_frame,
            text="Discord Server",
            command=self._open_discord,
            width=100,
            height=32,
            font=("Segoe UI", 11),
        )
        discord_btn.place(relx=0.0, x=12, y=12, anchor="nw")

        ctk.CTkLabel(
            title_frame,
            text="Elden Ring Save Manager",
            font=("Segoe UI", 20, "bold"),
        ).pack(pady=(10, 2))

        ctk.CTkLabel(
            title_frame,
            text="Complete save editor, backup manager, and corruption fixer",
            font=("Segoe UI", 11),
        ).pack(pady=(0, 10))

        # File Selection
        file_frame = ctk.CTkFrame(self.root, corner_radius=12)
        file_frame.grid(row=1, column=0, padx=12, pady=10, sticky="ew")

        # Game selector
        game_row = ctk.CTkFrame(file_frame, fg_color="transparent")
        game_row.pack(fill=tk.X, padx=12, pady=(12, 4))

        ctk.CTkLabel(game_row, text="Game:", font=("Segoe UI", 11)).pack(
            side=tk.LEFT, padx=(0, 8)
        )

        self._game_selector_var = tk.StringVar(value=PROFILES_BY_KEY["elden_ring"].name)
        game_names = [p.name for p in GAME_PROFILES]
        self._game_combo = ctk.CTkComboBox(
            game_row,
            values=game_names,
            variable=self._game_selector_var,
            state="readonly",
            width=260,
            command=self._on_game_changed,
        )
        self._game_combo.pack(side=tk.LEFT)

        ctk.CTkLabel(
            file_frame,
            text="Select a Save File",
            font=("Segoe UI", 12, "bold"),
        ).pack(anchor="w", padx=12, pady=(4, 4))

        self.file_path_var = tk.StringVar(value="")
        # Auto-load when valid file path is entered
        trace_variable(self.file_path_var, "w", self._on_file_path_changed)

        path_frame = ctk.CTkFrame(file_frame, corner_radius=8)
        path_frame.pack(fill=tk.X, padx=12, pady=(0, 12))

        ctk.CTkEntry(path_frame, textvariable=self.file_path_var).pack(
            side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 6), pady=10
        )

        _browse_btn = ctk.CTkButton(
            path_frame,
            text="Browse",
            command=self.browse_file,
            width=110,
        )
        _browse_btn.pack(side=tk.LEFT, padx=4, pady=10)
        self._file_load_buttons.append(_browse_btn)

        _autofind_btn = ctk.CTkButton(
            path_frame,
            text="Auto-Find",
            command=self.auto_detect,
            width=110,
        )
        _autofind_btn.pack(side=tk.LEFT, padx=4, pady=10)
        self._file_load_buttons.append(_autofind_btn)

        # Load button
        buttons_frame = ctk.CTkFrame(file_frame, corner_radius=8)
        buttons_frame.pack(fill=tk.X, pady=(6, 10), padx=12)

        _reload_btn = ctk.CTkButton(
            buttons_frame,
            text="Reload",
            command=self.load_save,
            width=160,
        )
        _reload_btn.pack(side=tk.LEFT, padx=6, pady=10)
        self._file_load_buttons.append(_reload_btn)

        ctk.CTkButton(
            buttons_frame,
            text="Backup Manager",
            command=self.show_backup_manager_standalone,
            width=160,
        ).pack(side=tk.LEFT, padx=6, pady=10)

        ctk.CTkButton(
            buttons_frame,
            text="Troubleshooting",
            command=self.open_troubleshooting,
            width=160,
        ).pack(side=tk.RIGHT, padx=6, pady=10)

        _itemgib_btn = ctk.CTkButton(
            buttons_frame,
            text="Item Gib",
            command=self._open_inventory_editor,
            width=200,
        )
        _itemgib_btn.pack(side=tk.RIGHT, padx=6, pady=10)
        self._file_load_buttons.append(_itemgib_btn)

        # Main content - tabbed interface (customtkinter)
        self.notebook = ctk.CTkTabview(
            self.root,
            width=1100,
            height=620,
            corner_radius=12,
            command=self._on_tab_changed,
        )
        self.notebook.grid(row=2, column=0, padx=12, pady=10, sticky="nsew")

        # Create all tabs
        self.create_tabs()

        # Status bar
        status_frame = ctk.CTkFrame(self.root, corner_radius=0)
        status_frame.grid(row=3, column=0, sticky="ew")

        ctk.CTkLabel(
            status_frame,
            textvariable=self.status_var,
            anchor="w",
            padx=8,
            pady=6,
        ).pack(fill=tk.X)

    def _on_game_changed(self, _value=None):
        """Rebuild notebook tabs for the newly selected game."""
        name = self._game_selector_var.get()
        profile = next((p for p in GAME_PROFILES if p.name == name), None)
        if profile is None:
            return

        self.active_game = profile.key

        # Clear save state - switching games means the loaded save is no longer relevant.
        # This prevents tab setup_ui() calls from accessing stale save data.
        self.save_file = None
        self.save_path = None
        self.file_path_var.set("")

        # Null out all tab references so _finalize_save_load doesn't call methods
        # on widgets that are about to be destroyed.
        self.dsr_save = None
        self.ds3_save = None

        for attr in (
            "inspector_tab",
            "char_mgmt_tab",
            "world_tab",
            "event_flags_tab",
            "gestures_tab",
            "appearance_tab",
            "steamid_tab",
            "hex_tab",
            "advanced_tab",
            "settings_tab",
            "dsr_inspector_tab",
            "dsr_editor_tab",
            "dsr_inventory_tab",
            "dsr_npc_tab",
            "dsr_world_tab",
            "dsr_flags_tab",
            "ds3_inspector_tab",
            "ds3_editor_tab",
            "ds3_inventory_tab",
            "ds3_bosses_tab",
            "ds3_world_tab",
        ):
            setattr(self, attr, None)

        # Rebuild notebook
        self.notebook.destroy()
        self.notebook = ctk.CTkTabview(
            self.root,
            width=1100,
            height=620,
            corner_radius=12,
            command=self._on_tab_changed,
        )
        self.notebook.grid(row=2, column=0, padx=12, pady=10, sticky="nsew")

        # Reset lazy-load flags
        self.tabs_loaded = {
            "Save Fixer": False,
            "Appearance": False,
            "Advanced Tools": False,
            "SteamID Patcher": False,
            "Hex Editor": False,
            "Gestures": False,
        }

        if profile.key == "elden_ring":
            self.create_tabs()
        else:
            self._create_other_game_tabs(profile)

    def create_tabs(self):
        """Create all Elden Ring tabs."""

        # Tab 1: Save Fixer
        self.notebook.add("Save Fixer")
        tab_inspector = self.notebook.tab("Save Fixer")
        self.inspector_tab = SaveInspectorTab(
            tab_inspector,
            lambda: self.save_file,
            lambda: self.save_path,
            self.load_save,
            self.show_character_details,
            self.on_slot_selected,
        )
        self.inspector_tab.setup_ui()

        # Tab 2: Character Management
        self.notebook.add("Character Management")
        tab_char_mgmt = self.notebook.tab("Character Management")
        self.char_mgmt_tab = CharacterManagementTab(
            tab_char_mgmt,
            lambda: self.save_file,
            lambda: self.save_path,
            self.reload_save,
            self.show_toast,
            self.is_game_running,
        )
        self.char_mgmt_tab.setup_ui()

        # Tab 3: Character Editor
        self.notebook.add("Character Editor")
        tab_character = self.notebook.tab("Character Editor")
        self.setup_character_editor_tab(tab_character)

        # Tab 4: Appearance
        self.notebook.add("Appearance")
        tab_appearance = self.notebook.tab("Appearance")
        self.appearance_tab = AppearanceTab(
            tab_appearance,
            lambda: self.save_file,
            lambda: self.save_path,
            self.load_save,
            self.show_toast,
        )
        self.appearance_tab.setup_ui()

        # Tab 5: World State
        self.notebook.add("World State")
        tab_world = self.notebook.tab("World State")
        self.world_tab = WorldStateTab(
            tab_world,
            lambda: self.save_file,
            lambda: self.save_path,
            self.load_save,
            lambda: self.selected_slot_index,
            self.show_toast,
        )
        self.world_tab.setup_ui()
        try:
            if getattr(sys, "frozen", False):
                _base = (
                    Path(sys._MEIPASS)
                    if hasattr(sys, "_MEIPASS")
                    else Path(sys.executable).parent
                )
            else:
                _base = Path(__file__).parent.parent.parent
            _map_path = _base / "resources" / "map.jpeg"
            if _map_path.exists():
                self.world_tab.set_map_image_path(str(_map_path))
        except Exception:
            pass

        # Tab 6: SteamID Patcher
        self.notebook.add("SteamID Patcher")
        tab_steamid = self.notebook.tab("SteamID Patcher")
        self.steamid_tab = SteamIDPatcherTab(
            tab_steamid,
            lambda: self.save_file,
            lambda: self.save_path,
            self.load_save,
            self.show_toast,
        )
        self.steamid_tab.setup_ui()

        # Tab 7: Event Flags
        self.notebook.add("Event Flags")
        tab_event_flags = self.notebook.tab("Event Flags")
        self.event_flags_tab = EventFlagsTab(
            tab_event_flags,
            lambda: self.save_file,
            lambda: self.save_path,
            self.load_save,
            self.show_toast,
        )
        self.event_flags_tab.setup_ui()

        # Tab 8: Gestures
        self.notebook.add("Gestures")
        tab_gestures = self.notebook.tab("Gestures")
        self.gestures_tab = GesturesRegionsTab(
            tab_gestures,
            lambda: self.save_file,
            lambda: self.save_path,
            self.load_save,
            self.show_toast,
        )
        self.gestures_tab.setup_ui()

        # Tab 9: Hex Editor - hidden for now
        _hex_hidden = ctk.CTkFrame(self.root, fg_color="transparent")
        self.hex_tab = HexEditorTab(_hex_hidden, lambda: self.save_file)
        self.hex_tab.setup_ui()

        # Tab 10: Advanced Tools
        self.notebook.add("Advanced Tools")
        tab_advanced = self.notebook.tab("Advanced Tools")
        self.advanced_tab = AdvancedToolsTab(
            tab_advanced,
            lambda: self.save_file,
            lambda: self.save_path,
            self.load_save,
            self.show_toast,
        )
        self.advanced_tab.setup_ui()

        # Tab 11: Settings
        self.notebook.add("Settings")
        tab_settings = self.notebook.tab("Settings")
        self.settings_tab = SettingsTab(
            tab_settings,
            get_save_path_callback=lambda: self.save_path,
            get_default_save_path_callback=lambda: self.default_save_path,
            active_game="elden_ring",
            root=self.root,
        )
        self.settings_tab.setup_ui()

    def _create_other_game_tabs(self, profile):
        """Create the reduced tab set for non-Elden Ring games."""

        if profile.key == "dark_souls_3":
            from er_save_manager.games.DS3.tabs import (
                DS3BossesTab,
                DS3EditorTab,
                DS3InspectorTab,
                DS3InventoryTab,
                DS3WorldStateTab,
            )

            self.notebook.add("Save Inspector")
            self.ds3_inspector_tab = DS3InspectorTab(
                self.notebook.tab("Save Inspector"),
                get_save=lambda: self.ds3_save,
                on_slot_selected=self._on_ds3_slot_edit,
            )
            self.ds3_inspector_tab.setup_ui()

            self.notebook.add("Character Editor")
            self.ds3_editor_tab = DS3EditorTab(
                self.notebook.tab("Character Editor"),
                get_save=lambda: self.ds3_save,
                get_save_path=lambda: self.save_path,
                show_toast=self.show_toast,
            )
            self.ds3_editor_tab.setup_ui()

            self.notebook.add("Inventory")
            self.ds3_inventory_tab = DS3InventoryTab(
                self.notebook.tab("Inventory"),
                get_save=lambda: self.ds3_save,
                get_save_path=lambda: self.save_path,
                show_toast=self.show_toast,
            )
            self.ds3_inventory_tab.setup_ui()

            self.notebook.add("Bosses")
            self.ds3_bosses_tab = DS3BossesTab(
                self.notebook.tab("Bosses"),
                get_save=lambda: self.ds3_save,
                get_save_path=lambda: self.save_path,
                show_toast=self.show_toast,
            )
            self.ds3_bosses_tab.setup_ui()

            self.notebook.add("World State")
            self.ds3_world_tab = DS3WorldStateTab(
                self.notebook.tab("World State"),
                get_save=lambda: self.ds3_save,
                get_save_path=lambda: self.save_path,
                show_toast=self.show_toast,
            )
            self.ds3_world_tab.setup_ui()

            self.notebook.add("SteamID Patcher")
            self.steamid_tab = SteamIDPatcherTab(
                self.notebook.tab("SteamID Patcher"),
                lambda: self.save_file,
                lambda: self.save_path,
                self.load_save,
                self.show_toast,
            )
            self.steamid_tab.setup_ui()
            self.steamid_tab.set_active_profile("Dark Souls III")

            self.notebook.add("Settings")
            self.settings_tab = SettingsTab(
                self.notebook.tab("Settings"),
                get_save_path_callback=lambda: self.save_path,
                get_default_save_path_callback=lambda: self.default_save_path,
                active_game="dark_souls_3",
                root=self.root,
            )
            self.settings_tab.setup_ui()
            return

        # DSR has no embedded SteamID - SteamID Patcher tab is not shown.
        # All other non-ER games get: SteamID Patcher + Settings.
        # Backup Manager is available via the top-level button, not as a tab.

        if profile.key != "dark_souls_remastered":
            self.notebook.add("SteamID Patcher")
            tab_steamid = self.notebook.tab("SteamID Patcher")
            self.steamid_tab = SteamIDPatcherTab(
                tab_steamid,
                lambda: self.save_file,
                lambda: self.save_path,
                self.load_save,
                self.show_toast,
            )
            self.steamid_tab.setup_ui()
            self.steamid_tab.set_active_profile(profile.name)

        if profile.key == "dark_souls_remastered":
            from er_save_manager.games.DSR.editor_tab import DSREditorTab
            from er_save_manager.games.DSR.inspector_tab import DSRInspectorTab
            from er_save_manager.games.DSR.inventory_tab import DSRInventoryTab
            from er_save_manager.games.DSR.npc_tab import DSRNPCTab
            from er_save_manager.games.DSR.world_state_tab import DSRWorldStateTab

            self.notebook.add("Save Inspector")
            self.dsr_inspector_tab = DSRInspectorTab(
                self.notebook.tab("Save Inspector"),
                get_dsr_save=lambda: self.dsr_save,
                on_slot_selected=self._on_dsr_slot_edit,
            )
            self.dsr_inspector_tab.setup_ui()

            self.notebook.add("Character Editor")
            self.dsr_editor_tab = DSREditorTab(
                self.notebook.tab("Character Editor"),
                get_dsr_save=lambda: self.dsr_save,
                get_save_path=lambda: self.save_path,
                show_toast=self.show_toast,
            )
            self.dsr_editor_tab.setup_ui()

            self.notebook.add("Inventory")
            self.dsr_inventory_tab = DSRInventoryTab(
                self.notebook.tab("Inventory"),
                get_dsr_save=lambda: self.dsr_save,
                get_save_path=lambda: self.save_path,
                show_toast=self.show_toast,
            )
            self.dsr_inventory_tab.setup_ui()

            self.notebook.add("NPCs & Bosses")
            self.dsr_npc_tab = DSRNPCTab(
                self.notebook.tab("NPCs & Bosses"),
                get_dsr_save=lambda: self.dsr_save,
                get_save_path=lambda: self.save_path,
                show_toast=self.show_toast,
            )
            self.dsr_npc_tab.setup_ui()

            self.notebook.add("Event Flags")
            from er_save_manager.games.DSR.event_flags_tab import DSREventFlagsTab

            self.dsr_flags_tab = DSREventFlagsTab(
                self.notebook.tab("Event Flags"),
                get_dsr_save=lambda: self.dsr_save,
                get_save_path=lambda: self.save_path,
                show_toast=self.show_toast,
            )
            self.dsr_flags_tab.setup_ui()

            self.notebook.add("World State")
            self.dsr_world_tab = DSRWorldStateTab(
                self.notebook.tab("World State"),
                get_dsr_save=lambda: self.dsr_save,
                get_save_path=lambda: self.save_path,
                show_toast=self.show_toast,
            )
            self.dsr_world_tab.setup_ui()

        self.notebook.add("Settings")
        tab_settings = self.notebook.tab("Settings")
        self.settings_tab = SettingsTab(
            tab_settings,
            get_save_path_callback=lambda: self.save_path,
            get_default_save_path_callback=lambda: self.default_save_path,
            active_game=profile.key,
            root=self.root,
        )
        self.settings_tab.setup_ui()

    def setup_character_editor_tab(self, parent):
        """Setup character editor tab with modular editors"""
        header = ctk.CTkLabel(
            parent,
            text="Character Editor",
            font=("Segoe UI", 18, "bold"),
        )
        header.pack(pady=(6, 12))

        container = ctk.CTkFrame(
            parent, corner_radius=10, fg_color=("gray86", "gray22")
        )
        container.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 12))

        # Slot selector bar
        select_frame = ctk.CTkFrame(container, fg_color=("gray76", "gray24"))
        select_frame.pack(fill=tk.X, padx=10, pady=(12, 8))

        ctk.CTkLabel(select_frame, text="Character Slot:").pack(
            side=ctk.LEFT, padx=(0, 10)
        )

        self.char_slot_var = ctk.StringVar(value="1")
        slot_combo = ctk.CTkComboBox(
            select_frame,
            variable=self.char_slot_var,
            values=[str(i) for i in range(1, 11)],
            state="readonly",
            width=200,
            command=lambda _e=None: self.load_character_for_edit(),
        )
        slot_combo.pack(side=ctk.LEFT, padx=(0, 12))

        ctk.CTkButton(
            select_frame,
            text="Load Character",
            command=self.load_character_for_edit,
            width=140,
        ).pack(side=ctk.LEFT)

        # Editor tabs
        editor_tabs = ctk.CTkTabview(
            container,
            width=900,
            height=520,
            fg_color=("gray90", "gray20"),
            segmented_button_fg_color=("gray80", "gray35"),
            segmented_button_selected_color=("#c9a0dc", "#6a4b85"),
            segmented_button_unselected_color=("gray70", "gray30"),
        )
        editor_tabs.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 12))

        def current_slot_index() -> int:
            try:
                # Extract slot number from display name "1 - Character Name"
                slot_display = self.char_slot_var.get()
                return int(slot_display.split(" - ")[0]) - 1
            except Exception:
                return -1

        # Stats editor
        stats_frame = editor_tabs.add("Stats")
        stats_frame = ctk.CTkFrame(stats_frame, fg_color="transparent")
        stats_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        self.stats_editor = StatsEditor(
            stats_frame,
            lambda: self.save_file,
            current_slot_index,
            lambda: self.save_path,
        )
        self.stats_editor.setup_ui()

        # Equipment editor - hidden until implementation is complete
        _equipment_hidden = ctk.CTkFrame(container, fg_color="transparent")
        self.equipment_editor = EquipmentEditor(
            _equipment_hidden,
            lambda: self.save_file,
            current_slot_index,
            lambda: self.save_path,
        )
        self.equipment_editor.setup_ui()

        # Character info editor
        info_tab = editor_tabs.add("Info")
        info_frame = ctk.CTkFrame(info_tab, fg_color="transparent")
        info_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        self.char_info_editor = CharacterInfoEditor(
            info_frame,
            lambda: self.save_file,
            current_slot_index,
            lambda: self.save_path,
        )
        self.char_info_editor.setup_ui()

        # Inventory editor
        inventory_tab = editor_tabs.add("Inventory")
        inventory_frame = ctk.CTkFrame(inventory_tab, fg_color="transparent")
        inventory_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        self.inventory_editor = InventoryEditor(
            inventory_frame,
            lambda: self.save_file,
            current_slot_index,
            lambda: self.save_path,
            self.ensure_raw_data_mutable,
            on_inventory_changed=self._on_inventory_changed,
            get_settings_callback=lambda: self.settings,
        )
        self.inventory_editor.setup_ui()

    def acknowledge_save_written(self) -> None:
        """Resnapshot the save file mtime after an internal write.

        Call this after any tab writes the save so the file watcher does not
        treat the internal change as an external modification.
        """
        self._update_watched_mtime()

    def _on_inventory_changed(self) -> None:
        """Refresh matchmaking weapon level floor after inventory changes."""
        self.acknowledge_save_written()
        try:
            slot_idx = int(self.char_slot_var.get()) - 1
            slot = self.save_file.characters[slot_idx]
            if hasattr(self, "stats_editor") and self.stats_editor:
                self.stats_editor._refresh_matchmaking_min(slot)
        except Exception:
            pass

    def load_character_for_edit(self):
        """Load character data into editors"""

        if not self.save_file:
            CTkMessageBox.showwarning(
                "No Save", "Please load a save file first!", parent=self.root
            )
            return

        try:
            # Extract slot number from display name "1 - Character Name"
            slot_display = self.char_slot_var.get()
            slot_idx = int(slot_display.split(" - ")[0]) - 1
        except Exception:
            CTkMessageBox.showwarning(
                "Invalid Slot", "Please choose a character slot.", parent=self.root
            )
            return

        slot = self.save_file.characters[slot_idx]

        if slot.is_empty():
            CTkMessageBox.showwarning(
                "Empty Slot", f"Slot {slot_idx + 1} is empty!", parent=self.root
            )
            return

        # Load into all editors
        self.stats_editor.load_stats()
        self.equipment_editor.load_equipment()
        self.char_info_editor.load_character_info()
        self.inventory_editor.refresh_inventory()

        self.status_var.set(f"Loaded character from Slot {slot_idx + 1}")

    def ensure_raw_data_mutable(self):
        """Ensure save file _raw_data is mutable (bytearray)"""
        if self.save_file and isinstance(self.save_file._raw_data, bytes):
            self.save_file._raw_data = bytearray(self.save_file._raw_data)

    def _active_profile(self):
        """Return the GameProfile for the currently selected game."""
        return PROFILES_BY_KEY.get(self.active_game)

    # File operations
    def browse_file(self):
        """Browse for a save file for the active game."""
        profile = self._active_profile()

        # Block loading if the game is currently running
        if (
            not self.settings.get("skip_game_running_check", False)
            and profile
            and profile.process_name
            and self.is_game_running(profile.process_name)
        ):
            if not self._handle_game_running_dialog(profile):
                return

        initialdir = None
        if self.settings.get("remember_last_location", True):
            last_path = self.settings.get("last_save_path", "")
            if last_path:
                last_dir = os.path.dirname(last_path)
                if os.path.exists(last_dir):
                    initialdir = last_dir

        if not initialdir:
            # Try the game's default save location
            default_loc = PlatformUtils.get_default_save_location(profile)
            if default_loc and default_loc.exists():
                initialdir = str(default_loc)

        if not initialdir:
            # ER legacy fallback
            if self.default_save_path.exists():
                initialdir = str(self.default_save_path)

        if not initialdir and PlatformUtils.is_linux():
            steam_base = Path.home() / ".local" / "share" / "Steam"
            if steam_base.exists():
                initialdir = str(steam_base)

        if not initialdir:
            initialdir = str(Path.home())

        # Build file type filter from profile extensions
        if profile:
            ext_str = " ".join(f"*{e}" for e in profile.extensions)
            filetypes = [(f"{profile.name} Saves", ext_str), ("All files", "*.*")]
            title = f"Select {profile.name} Save File"
        else:
            filetypes = [("Save Files", "*.sl2 *.co2 *.cnv"), ("All files", "*.*")]
            title = "Select Save File"

        filename = filedialog.askopenfilename(
            title=title,
            initialdir=initialdir,
            filetypes=filetypes,
        )
        if filename:
            self.file_path_var.set(filename)
            self.status_var.set(f"Selected: {os.path.basename(filename)}")

            if self.settings.get("remember_last_location", True):
                self.settings.set("last_save_path", filename)

            if (
                PlatformUtils.is_linux()
                and not PlatformUtils.is_save_in_default_location(
                    Path(filename), profile
                )
                and self.settings.get("show_linux_save_warning", True)
            ):
                self.show_linux_save_location_warning(Path(filename), profile)

    def auto_detect(self):
        """Auto-detect save file for the active game."""
        profile = self._active_profile()
        found_saves = PlatformUtils.find_all_save_files(profile)
        game_name = profile.name if profile else "Elden Ring"

        if not found_saves:
            if PlatformUtils.is_linux():
                CTkMessageBox.showinfo(
                    "No Saves Found",
                    f"No {game_name} save files found.\n\n"
                    "Make sure you have launched the game at least once.\n"
                    "On Linux, saves are stored in Steam's compatdata folder.",
                    parent=self.root,
                )
            else:
                CTkMessageBox.showwarning(
                    "Not Found",
                    f"No {game_name} save files found.",
                    parent=self.root,
                )
            return

        def _on_selected(path: str):
            self.file_path_var.set(path)
            if (
                PlatformUtils.is_linux()
                and not PlatformUtils.is_save_in_default_location(Path(path), profile)
                and self.settings.get("show_linux_save_warning", True)
            ):
                self.show_linux_save_location_warning(Path(path), profile)

        if len(found_saves) == 1:
            _on_selected(str(found_saves[0]))
            self.status_var.set(f"{game_name} save auto-detected")
        else:
            SaveSelectorDialog.show(self.root, found_saves, _on_selected)

    def show_linux_save_location_warning(self, save_path, profile=None):
        """Show warning about non-default save location on Linux."""
        game_name = profile.name if profile else "Elden Ring"
        dialog = tk.Toplevel(self.root)
        dialog.title("Save Location Warning")
        dialog.geometry("550x500")
        dialog.transient(self.root)

        msg_frame = ttk.Frame(dialog, padding=20)
        msg_frame.pack(fill=tk.BOTH, expand=True)

        ttk.Label(
            msg_frame,
            text="Non-Standard Save Location",
            font=("Segoe UI", 12, "bold"),
            foreground="orange",
        ).pack(pady=(0, 10))

        warning_text = (
            f"Your {game_name} save file is located in:\n"
            f"{save_path}\n\n"
            f"This is NOT the default Steam compatdata location!\n\n"
            f'If you remove the custom launcher (e.g. "ersc_launcher.exe") from Steam, '
            f"Steam will remove that compatdata folder and your save will get lost.\n\n"
            f"Recommended: Set a fixed Steam launch option and copy the save file to the "
            f"default location via the 'Copy Save' button below to prevent this."
        )

        ttk.Label(
            msg_frame,
            text=warning_text,
            wraplength=500,
            justify=tk.LEFT,
        ).pack(pady=10)

        # Show launch option
        launch_option = PlatformUtils.get_steam_launch_option_hint(profile)
        if launch_option:
            ttk.Label(
                msg_frame,
                text="Add this to the custom launcher's Steam launch options:",
                font=("Segoe UI", 9, "bold"),
            ).pack(anchor=tk.W, pady=(10, 5))

            option_frame = ttk.Frame(msg_frame)
            option_frame.pack(fill=tk.X, pady=5)

            option_entry = ttk.Entry(option_frame, font=("Consolas", 11))
            option_entry.insert(0, launch_option)
            option_entry.config(state="readonly")
            option_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))

            def copy_to_clipboard():
                dialog.clipboard_clear()
                dialog.clipboard_append(launch_option)
                dialog.update()
                CTkMessageBox.showinfo(
                    "Copied", "Launch option copied to clipboard!", parent=dialog
                )

            ctk.CTkButton(
                option_frame, text="Copy", command=copy_to_clipboard, width=80
            ).pack(side=tk.LEFT, padx=5)

        def copy_to_default():
            target_dir = PlatformUtils.get_default_save_location(profile)
            current_path = Path(save_path)
            steamid = current_path.parent.name
            if target_dir and steamid:
                target_dir = target_dir / steamid

            if target_dir:
                if CTkMessageBox.askyesno(
                    "Copy Save",
                    f"Copy save file to:\n{target_dir}\n\nThe original file will remain in its current location.",
                    parent=self.root,
                ):
                    try:
                        import shutil

                        target_dir.mkdir(parents=True, exist_ok=True)
                        new_path = target_dir / current_path.name
                        shutil.copy2(save_path, new_path)
                        self.file_path_var.set(str(new_path))
                        CTkMessageBox.showinfo(
                            "Success",
                            f"Save file copied to:\n{new_path}\n\nOriginal file remains at:\n{save_path}",
                            parent=self.root,
                        )
                        dialog.destroy()
                    except Exception as e:
                        CTkMessageBox.showerror(
                            "Error", f"Failed to copy save:\n{e}", parent=self.root
                        )

        def dont_show_again():
            self.settings.set("show_linux_save_warning", False)
            dialog.destroy()

        button_frame = ttk.Frame(msg_frame)
        button_frame.pack(pady=10)

        ttk.Button(
            button_frame, text="Copy to Default", command=copy_to_default, width=18
        ).pack(side=tk.LEFT, padx=5)
        ttk.Button(
            button_frame, text="Keep Current", command=dialog.destroy, width=15
        ).pack(side=tk.LEFT, padx=5)
        ttk.Button(
            button_frame, text="Don't Show Again", command=dont_show_again, width=18
        ).pack(side=tk.LEFT, padx=5)

    def is_game_running(self, process_name: str = "eldenring.exe") -> bool:
        """Check if a game process is running."""
        if process_name == "eldenring.exe":
            return PlatformUtils.is_game_running()
        try:
            if PlatformUtils.is_windows():
                si = subprocess.STARTUPINFO()
                si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                si.wShowWindow = 0  # SW_HIDE
                result = subprocess.run(
                    ["tasklist", "/FI", f"IMAGENAME eq {process_name}", "/NH"],
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.DEVNULL,
                    startupinfo=si,
                    creationflags=subprocess.CREATE_NO_WINDOW,
                )
                return (
                    process_name.lower()
                    in result.stdout.decode(errors="replace").lower()
                )
            else:
                result = subprocess.run(
                    ["pgrep", "-f", process_name],
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                )
                return result.returncode == 0
        except Exception:
            return False

    def _get_game_folder(self) -> Path | None:
        """Attempt to detect the Elden Ring installation folder."""
        try:
            # Try to find via Steam registry on Windows
            if PlatformUtils.is_windows():
                import winreg

                # Try to read Steam install path from registry
                try:
                    key = winreg.OpenKey(
                        winreg.HKEY_LOCAL_MACHINE,
                        r"SOFTWARE\WOW6432Node\Valve\Steam",
                    )
                    steam_path = Path(winreg.QueryValueEx(key, "InstallPath")[0])
                    winreg.CloseKey(key)

                    # Check common Steam library locations
                    game_folder = steam_path / "steamapps" / "common" / "ELDEN RING"
                    if game_folder.exists():
                        return game_folder

                    # Check libraryfolders.vdf for additional libraries
                    library_file = steam_path / "steamapps" / "libraryfolders.vdf"
                    if library_file.exists():
                        content = library_file.read_text(encoding="utf-8")
                        # Simple parse for paths (not perfect VDF parsing)
                        import re

                        paths = re.findall(r'"path"\s+"(.+?)"', content)
                        for path_str in paths:
                            lib_path = Path(path_str.replace("\\\\", "\\"))
                            game_folder = (
                                lib_path / "steamapps" / "common" / "ELDEN RING"
                            )
                            if game_folder.exists():
                                return game_folder

                except Exception:
                    pass

            # Fallback: Check common default locations
            common_paths = [
                Path("C:/Program Files (x86)/Steam/steamapps/common/ELDEN RING"),
                Path("C:/Program Files/Steam/steamapps/common/ELDEN RING"),
                Path.home()
                / ".steam"
                / "steam"
                / "steamapps"
                / "common"
                / "ELDEN RING",
                Path.home()
                / ".local"
                / "share"
                / "Steam"
                / "steamapps"
                / "common"
                / "ELDEN RING",
            ]

            for path in common_paths:
                if path.exists():
                    return path

        except Exception:
            pass

        return None

    def _open_inventory_editor(self):
        """Navigate to the inventory editor for the active game."""
        if self.active_game == "dark_souls_remastered":
            try:
                self.notebook.set("Inventory")
            except Exception:
                pass
            return
        """Navigate to Character Editor > Inventory tab."""
        self.notebook.set("Character Editor")
        if hasattr(self, "inventory_editor"):
            # Find the inner editor_tabs and activate Inventory
            try:
                for widget in self.notebook.tab("Character Editor").winfo_children():
                    if isinstance(widget, ctk.CTkFrame):
                        for child in widget.winfo_children():
                            if isinstance(child, ctk.CTkTabview):
                                child.set("Inventory")
                                break
            except Exception:
                pass

    def open_troubleshooting(self):
        """Open the troubleshooting dialog or install addon"""
        from er_save_manager.addons.troubleshooter_addon_manager import (
            TroubleshooterAddon,
        )
        from er_save_manager.addons.troubleshooter_install_dialog import (
            show_troubleshooter_dialog,
        )

        addon_manager = TroubleshooterAddon()
        show_troubleshooter_dialog(self.root, addon_manager)

    def _on_tab_changed(self, event=None):
        """Handle tab change event - lazy load and refresh tabs."""
        current_tab = self.notebook.get()

        # Load tab content in background for non-blocking UI
        if not self.tabs_loaded.get(current_tab, False):
            thread = threading.Thread(
                target=self._lazy_load_tab_background, args=(current_tab,), daemon=True
            )
            thread.start()
        elif current_tab == "World State" and hasattr(self, "world_tab"):
            # Already loaded, just refresh
            self.world_tab.refresh()

    def _lazy_load_tab_background(self, tab_name):
        """Schedule tab data load on the main thread -- all CTk calls must stay on the main thread."""
        # Nothing here is actually safe to run off-thread; dispatch everything via after().
        self.root.after(0, lambda: self._lazy_load_tab_main(tab_name))

    def _lazy_load_tab_main(self, tab_name):
        """Load tab data on the main thread."""
        try:
            if not self.save_file:
                return
            if self.tabs_loaded.get(tab_name, False):
                return

            if tab_name == "Save Fixer":
                self.inspector_tab.populate_character_list()
            elif tab_name == "Appearance":
                self.appearance_tab.load_presets()
            elif tab_name == "Advanced Tools":
                self.advanced_tab.update_save_info()
            elif tab_name == "Event Flags":
                if hasattr(self, "dsr_flags_tab") and self.dsr_flags_tab:
                    self.dsr_flags_tab.refresh()
            elif tab_name == "SteamID Patcher":
                if hasattr(self.steamid_tab, "update_steamid_display"):
                    self.steamid_tab.update_steamid_display()
            elif tab_name == "Hex Editor":
                if self.save_file:
                    try:
                        with open(self.save_path, "rb") as f:
                            self.save_file._raw_data = f.read()
                        self.hex_tab.hex_display_at_offset(0)
                    except Exception:
                        pass
            # "Gestures" has no auto-load

            self.tabs_loaded[tab_name] = True
        except Exception:
            pass

    def _on_file_path_changed(self, *args):
        """Auto-load save file when a valid file path is entered."""
        save_path = self.file_path_var.get()
        if not save_path or not os.path.exists(save_path):
            return

        if self.active_game == "elden_ring":
            filename = os.path.basename(save_path).lower()
            if filename.startswith("er"):
                self.root.after(500, self.load_save)
        elif self.active_game == "dark_souls_remastered":
            self.root.after(500, lambda p=save_path: self._load_dsr_save(p))
        elif self.active_game == "dark_souls_3":
            self.root.after(500, lambda p=save_path: self._load_ds3_save(p))
        else:
            self._load_non_er_save(save_path)

    def _load_non_er_save(self, save_path: str):
        """Store the selected save path for non-ER games and refresh the SteamID display."""
        profile = self._active_profile()
        if (
            not self.settings.get("skip_game_running_check", False)
            and profile
            and profile.process_name
            and self.is_game_running(profile.process_name)
        ):
            if not self._handle_game_running_dialog(profile):
                return

        self.save_path = Path(save_path)
        self.save_file = None
        self.status_var.set(f"Selected: {os.path.basename(save_path)}")
        self.show_toast(
            f"Save file loaded: {os.path.basename(save_path)}", duration=2500
        )
        if hasattr(self, "steamid_tab") and self.steamid_tab:
            import threading

            threading.Thread(
                target=self.steamid_tab._refresh_steamid_display, daemon=True
            ).start()

    def on_slot_selected(self, slot_index: int):
        """Handle character slot selection from Fixer tab."""
        self.selected_slot_index = slot_index

    def load_save(self, silent=False):
        """Load save file in background thread to prevent UI freezing

        Args:
            silent: If True, suppress the success message (used for reloads after operations)
        """
        save_path = self.file_path_var.get()

        if not save_path or not os.path.exists(save_path):
            CTkMessageBox.showerror(
                "Error", "Please select a valid save file first!", parent=self.root
            )
            return

        # Check if game is running - MUST be closed
        profile = self._active_profile()
        process_name = (
            profile.process_name
            if profile and profile.process_name
            else "eldenring.exe"
        )
        if not self.settings.get(
            "skip_game_running_check", False
        ) and self.is_game_running(process_name):
            if not self._handle_game_running_dialog(profile):
                return

        # EAC warning only applies to Elden Ring .sl2 files
        if (
            self.active_game == "elden_ring"
            and save_path.lower().endswith(".sl2")
            and self.settings.get("show_eac_warning", True)
        ):
            # Create custom dialog with "Don't show again" option
            warning_dialog = tk.Toplevel(self.root)
            warning_dialog.title("⚠️ Warning - Vanilla Save File Detected")
            warning_dialog.geometry("520x600")
            warning_dialog.transient(self.root)
            warning_dialog.update_idletasks()
            warning_dialog.grab_set()

            # Warning message
            msg_frame = ttk.Frame(warning_dialog, padding=20)
            msg_frame.pack(fill=tk.BOTH, expand=True)

            ttk.Label(
                msg_frame,
                text="⚠️ Warning - Vanilla Save File Detected",
                font=("Segoe UI", 12, "bold"),
                foreground="red",
            ).pack(pady=(0, 10))

            warning_text = (
                "You are loading a Vanilla save file (.sl2).\n\n"
                "WARNING: Modifying save files can result in a BAN if:\n"
                "• You connect to the official servers having modified saves\n\n"
                "What should be fine:\n"
                "• Corruption Fixes and Teleports\n"
                "• Spawning in valid items, runes, modifying NG count, gestures, event flags, changing invasion zones\n\n"
                "What will ban you:\n"
                "• Editing attributes to invalid values, spawning in cut content, spawning in DLC spells without owning it\n"
                "• If you think it might ban you it probably will\n\n"
                "If you play the vanilla game offline you will be fine.\n\n"
                "Do you understand and want to continue?"
            )

            ttk.Label(
                msg_frame,
                text=warning_text,
                wraplength=470,
                justify=tk.LEFT,
            ).pack(pady=10)

            # Don't show again checkbox
            dont_show_var = tk.BooleanVar(value=False)
            ttk.Checkbutton(
                msg_frame,
                text="Don't show this warning again",
                variable=dont_show_var,
            ).pack(pady=10)

            # Buttons
            button_frame = ttk.Frame(msg_frame)
            button_frame.pack(pady=10)

            result = {"continue": False}

            def on_yes():
                if dont_show_var.get():
                    self.settings.set("show_eac_warning", False)
                result["continue"] = True
                warning_dialog.destroy()

            def on_no():
                result["continue"] = False
                warning_dialog.destroy()

            ttk.Button(
                button_frame, text="Yes, Continue", command=on_yes, width=15
            ).pack(side=tk.LEFT, padx=5)
            ttk.Button(button_frame, text="No, Cancel", command=on_no, width=15).pack(
                side=tk.LEFT, padx=5
            )

            # Wait for dialog to close
            self.root.wait_window(warning_dialog)

            if not result["continue"]:
                self.status_var.set("Load cancelled by user")
                return

        # Route non-ER games to their own loaders so the Load button works too
        if self.active_game == "dark_souls_remastered":
            self._load_dsr_save(save_path)
            return
        if self.active_game == "dark_souls_3":
            self._load_ds3_save(save_path)
            return

        # Start loading in background thread
        self.status_var.set("Loading save file...")
        thread = threading.Thread(
            target=self._load_save_background, args=(save_path, silent), daemon=True
        )
        thread.start()

    def _load_save_background(self, save_path, silent=False):
        """Background thread for loading save file"""
        try:
            verbose = self.settings.get("verbose_logging", False)
            if verbose:
                self._verbose_log(f"Loading save: {save_path}")

            # Load save file in background
            save_file = Save.from_file(save_path)

            if verbose:
                self._verbose_log(f"Parsed successfully: {save_path}")

            # Update main thread
            self.root.after(0, self._finalize_save_load, save_file, save_path, silent)
        except Exception as e:
            error_msg = str(e)
            if self.settings.get("verbose_logging", False):
                self._verbose_log(f"Load failed: {save_path} -- {error_msg}")

            self.root.after(
                0,
                lambda: CTkMessageBox.showerror(
                    "Error", f"Failed to load save file:\n{error_msg}", parent=self.root
                ),
            )
            self.root.after(0, lambda: self.status_var.set("Load failed"))

    def _load_dsr_save(self, save_path: str) -> None:
        """Parse a DSR save file and refresh all DSR tabs."""
        from er_save_manager.games.DSR.save import DSRSave

        profile = self._active_profile()
        if (
            not self.settings.get("skip_game_running_check", False)
            and profile
            and profile.process_name
            and self.is_game_running(profile.process_name)
        ):
            if not self._handle_game_running_dialog(profile):
                return

        try:
            self.dsr_save = DSRSave.from_file(save_path)
        except Exception as e:
            CTkMessageBox.showerror(
                "Error", f"Failed to load DSR save:\n{e}", parent=self.root
            )
            return

        self.save_path = Path(save_path)
        self.save_file = None

        for attr in (
            "dsr_inspector_tab",
            "dsr_editor_tab",
            "dsr_inventory_tab",
            "dsr_npc_tab",
            "dsr_flags_tab",
            "dsr_world_tab",
        ):
            tab = getattr(self, attr, None)
            if tab is not None:
                tab.refresh()

        self.status_var.set(f"Loaded: {os.path.basename(save_path)}")
        self.show_toast(
            f"DSR save loaded: {os.path.basename(save_path)}", duration=2500
        )

    def _on_dsr_slot_edit(self, slot_idx: int) -> None:
        """Navigate to Character Editor and load the selected slot.
        Called only from the inspector 'Edit Character' button - never from row clicks.
        """
        try:
            self.notebook.set("Character Editor")
        except Exception:
            pass
        if hasattr(self, "dsr_editor_tab") and self.dsr_editor_tab:
            self.dsr_editor_tab.load_slot(slot_idx)

    def _load_ds3_save(self, save_path: str) -> None:
        """Parse a DS3 save file and refresh all DS3 tabs."""
        from er_save_manager.games.DS3.save import DS3Save

        profile = self._active_profile()
        if (
            not self.settings.get("skip_game_running_check", False)
            and profile
            and profile.process_name
            and self.is_game_running(profile.process_name)
        ):
            if not self._handle_game_running_dialog(profile):
                return

        try:
            self.ds3_save = DS3Save.from_file(save_path)
        except Exception as e:
            CTkMessageBox.showerror(
                "Error", f"Failed to load DS3 save:\n{e}", parent=self.root
            )
            return

        self.save_path = Path(save_path)
        self.save_file = None

        for attr in (
            "ds3_inspector_tab",
            "ds3_editor_tab",
            "ds3_inventory_tab",
            "ds3_bosses_tab",
            "ds3_world_tab",
        ):
            tab = getattr(self, attr, None)
            if tab is not None:
                tab.refresh()

        self.status_var.set(f"Loaded: {os.path.basename(save_path)}")
        self.show_toast(
            f"DS3 save loaded: {os.path.basename(save_path)}", duration=2500
        )

    def reload_save(self):
        """Reload the current save file without showing success message"""
        self.load_save(silent=True)

    def _on_ds3_slot_edit(self, slot_idx: int) -> None:
        """Navigate to Character Editor and load the selected slot.
        Called only from the DS3 inspector 'Edit Character' button.
        """
        try:
            self.notebook.set("Character Editor")
        except Exception:
            pass
        for attr in (
            "ds3_editor_tab",
            "ds3_inventory_tab",
            "ds3_bosses_tab",
            "ds3_world_tab",
        ):
            tab = getattr(self, attr, None)
            if tab is not None:
                tab.load_slot(slot_idx)

        """Reload the current save file without showing success message"""
        self.load_save(silent=True)

    def _finalize_save_load(self, save_file, save_path, silent=False):
        """Finalize save loading on main thread"""
        self.save_file = save_file
        self.save_path = Path(save_path)
        self._update_watched_mtime()
        self._start_file_watcher()

        if self.active_game == "elden_ring":
            if hasattr(self, "char_mgmt_tab") and self.char_mgmt_tab:
                self.char_mgmt_tab.refresh_slot_names()
            if hasattr(self, "world_tab") and self.world_tab:
                self.world_tab.refresh_slot_names()
            if hasattr(self, "event_flags_tab") and self.event_flags_tab:
                self.event_flags_tab.refresh_slot_names()
            if hasattr(self, "gestures_tab") and self.gestures_tab:
                self.gestures_tab.refresh_slot_names()
            self._update_character_editor_slots()

        # Reset all tab flags so views will refresh with the new save
        for tab_name in self.tabs_loaded:
            self.tabs_loaded[tab_name] = False

        # Lazy-load the currently visible tab immediately (ensures live refresh)
        current_tab = self.notebook.get()
        self._lazy_load_tab_background(current_tab)

        self.status_var.set(f"Loaded: {os.path.basename(save_path)}")
        if not silent:
            # Show toast notification instead of blocking popup
            self.show_toast("Save file loaded successfully!", duration=2500)

    def _update_character_editor_slots(self):
        """Update Character Editor slot dropdown with character names"""
        if not self.save_file:
            return

        slot_names = []
        profiles = None

        try:
            if self.save_file.user_data_10_parsed:
                profiles = self.save_file.user_data_10_parsed.profile_summary.profiles
        except Exception:
            pass

        for i in range(10):
            slot_num = i + 1
            char = self.save_file.characters[i]

            if char.is_empty():
                slot_names.append(f"{slot_num} - Empty")
                continue

            char_name = "Unknown"
            if profiles and i < len(profiles):
                try:
                    char_name = profiles[i].character_name or "Unknown"
                except Exception:
                    pass

            slot_names.append(f"{slot_num} - {char_name}")

        # Update the combobox values
        if hasattr(self, "char_slot_var"):
            # Find the combobox widget and update its values
            # The combobox is in the character editor tab
            for widget in self.root.winfo_children():
                self._update_combobox_recursive(widget, slot_names)

    def _update_combobox_recursive(self, widget, values):
        """Recursively find and update character slot combobox"""
        try:
            if isinstance(widget, ctk.CTkComboBox):
                if (
                    hasattr(widget, "cget")
                    and widget.cget("variable") == self.char_slot_var
                ):
                    current = self.char_slot_var.get()
                    widget.configure(values=values)
                    # Restore selection if valid
                    if current.isdigit() and 0 < int(current) <= 10:
                        idx = int(current) - 1
                        if idx < len(values):
                            self.char_slot_var.set(values[idx])
                    return

            # Recurse into children
            for child in widget.winfo_children():
                self._update_combobox_recursive(child, values)
        except Exception:
            pass

    def show_character_details(self, slot_idx):
        """Show character details dialog"""
        CharacterDetailsDialog.show(
            self.root, self.save_file, slot_idx, self.save_path, self.load_save
        )

    def show_backup_manager_standalone(self):
        """Show backup manager from top button."""
        try:
            profile = PROFILES_BY_KEY.get(self.active_game)
            if not profile:
                return

            if not hasattr(self, "_backup_tab_helper"):
                self._backup_tab_helper = BackupManagerTab(
                    self.root,
                    lambda: self.save_file,
                    lambda: self.save_path,
                    self.load_save,
                    self.show_toast,
                )

            self._backup_tab_helper.open_for_profile(profile)

        except Exception as e:
            CTkMessageBox.showerror(
                "Error", f"Failed to open backup manager:\n{e}", parent=self.root
            )

    def _update_watched_mtime(self) -> None:
        """Snapshot the current mtime of the loaded save file."""
        try:
            if self.save_path and self.save_path.exists():
                self._watched_mtime = self.save_path.stat().st_mtime
        except OSError:
            self._watched_mtime = None

    def _start_file_watcher(self) -> None:
        """Start the external-modification poll loop if not already running."""
        if self._file_watcher_running:
            return
        self._file_watcher_running = True
        self.root.after(3000, self._poll_file_change)

    def _poll_file_change(self) -> None:
        """Poll for external save modifications every 3 seconds.

        Sets a pending flag instead of showing the dialog immediately so the
        user is only notified when they refocus the window.
        """
        if not self.save_file or not self.save_path:
            self._file_watcher_running = False
            return

        try:
            current_mtime = self.save_path.stat().st_mtime
        except OSError:
            self.root.after(3000, self._poll_file_change)
            return

        if self._watched_mtime is not None and current_mtime != self._watched_mtime:
            self._watched_mtime = current_mtime
            self._pending_file_change = True

        self.root.after(3000, self._poll_file_change)

    def _on_window_focus(self, event=None) -> None:
        """Show the external-modification dialog when the window regains focus."""
        # Only fire for the root window itself, not child widgets gaining focus
        if event is not None and event.widget is not self.root:
            return
        if not self._pending_file_change or self._file_change_dialog_open:
            return
        if not self.settings.get("external_file_change_notification", True):
            self._pending_file_change = False
            return

        self._pending_file_change = False
        self._file_change_dialog_open = True

        dialog = ctk.CTkToplevel(self.root)
        dialog.title("Save File Modified")
        dialog.geometry("440x250")
        dialog.transient(self.root)
        dialog.resizable(False, False)

        dialog.update_idletasks()
        px = self.root.winfo_x() + (self.root.winfo_width() - 440) // 2
        py = self.root.winfo_y() + (self.root.winfo_height() - 250) // 2
        dialog.geometry(f"440x250+{px}+{py}")

        main = ctk.CTkFrame(dialog, fg_color="transparent")
        main.pack(fill=ctk.BOTH, expand=True, padx=24, pady=24)

        ctk.CTkLabel(
            main,
            text="Save Modified Externally",
            font=("Segoe UI", 18, "bold"),
        ).pack(pady=(0, 22))

        ctk.CTkLabel(
            main,
            text=(
                f"{self.save_path.name} was changed while the save manager\n"
                "had it loaded. Reload to avoid overwriting those changes."
            ),
            font=("Segoe UI", 16),
            justify=ctk.CENTER,
            wraplength=380,
        ).pack(pady=(0, 24))

        btn_row = ctk.CTkFrame(main, fg_color="transparent")
        btn_row.pack()

        def on_reload():
            self._file_change_dialog_open = False
            dialog.destroy()
            self.reload_save()

        def on_dismiss():
            if disable_var.get():
                self.settings.set("external_file_change_notification", False)
            self._file_change_dialog_open = False
            dialog.destroy()

        dialog.protocol("WM_DELETE_WINDOW", on_dismiss)

        ctk.CTkButton(btn_row, text="Reload Now", width=120, command=on_reload).pack(
            side=ctk.LEFT, padx=(0, 8)
        )
        ctk.CTkButton(
            btn_row,
            text="Dismiss",
            width=100,
            fg_color="transparent",
            border_width=1,
            command=on_dismiss,
        ).pack(side=ctk.LEFT)

        disable_var = ctk.BooleanVar(value=False)
        ctk.CTkCheckBox(
            main,
            text="Don't show this again",
            variable=disable_var,
            font=("Segoe UI", 11),
        ).pack(pady=(14, 0))

    def _verbose_log(self, message: str) -> None:
        """Write a timestamped line to the verbose log file next to the current save."""
        import datetime

        save_path = self.file_path_var.get() if hasattr(self, "file_path_var") else ""
        log_dir = Path(save_path).parent if save_path else Path.home()
        log_path = log_dir / "er_save_manager.log"
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        try:
            with open(log_path, "a", encoding="utf-8") as f:
                f.write(f"[{timestamp}] {message}\n")
        except OSError:
            pass


def main():
    """Main entry point for GUI"""
    root = ctk.CTk()
    app = SaveManagerGUI(root)

    # Register cleanup handler
    def on_closing():
        if app.process_monitor:
            app.process_monitor.stop()
        root.destroy()

    root.protocol("WM_DELETE_WINDOW", on_closing)
    root.mainloop()


if __name__ == "__main__":
    main()
