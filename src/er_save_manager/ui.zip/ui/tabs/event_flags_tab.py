"""
Event Flags Tab (customtkinter version)
Comprehensive event flag viewer and editor with 948 documented flags
"""

import tkinter as tk

import customtkinter as ctk

from er_save_manager.backup.manager import BackupManager
from er_save_manager.data.boss_data import (
    BOSS_CATEGORIES,
    get_boss_flags,
    get_bosses_by_category,
)
from er_save_manager.data.event_flags_db import (
    CATEGORIES,
    get_category_flags,
    get_flag_name,
    get_subcategories,
)
from er_save_manager.data.summoning_pools_data import (
    SUMMONING_POOL_FLAGS_BASE,
    SUMMONING_POOL_FLAGS_DLC,
)
from er_save_manager.parser.event_flags import EventFlags
from er_save_manager.ui.messagebox import CTkMessageBox
from er_save_manager.ui.utils import bind_mousewheel


class EventFlagsTab:
    """Tab for event flag viewing and management (customtkinter version)"""

    class _EventFlagAccessor:
        """Adapter that wraps slot.event_flags bytes with get/set helpers."""

        def __init__(self, slot):
            self.slot = slot
            # Keep a mutable buffer for repeated writes
            self.buffer = (
                bytearray(slot.event_flags)
                if not isinstance(slot.event_flags, bytearray)
                else slot.event_flags
            )

        def get_flag(self, flag_id: int) -> bool:
            return EventFlags.get_flag(bytes(self.buffer), flag_id)

        def set_flag(self, flag_id: int, state: bool) -> None:
            EventFlags.set_flag(self.buffer, flag_id, state)
            # Persist back onto the slot so saves use updated bytes
            self.slot.event_flags = bytes(self.buffer)

    def __init__(
        self,
        parent,
        get_save_file_callback,
        get_save_path_callback,
        reload_callback,
        show_toast_callback,
    ):
        self.show_toast = show_toast_callback
        """
        Initialize event flags tab

        Args:
            parent: Parent widget
            get_save_file_callback: Function that returns current save file
            get_save_path_callback: Function that returns save file path
            reload_callback: Function to reload save file
        """
        self.parent = parent
        self.get_save_file = get_save_file_callback
        self.get_save_path = get_save_path_callback
        self.reload_save = reload_callback

        self.eventflag_slot_var = None
        self.current_slot = None
        self.category_var = None
        self.subcategory_var = None
        self.search_var = None
        self.flag_states = {}  # Track checkbox states
        self.flag_widgets = {}  # Track checkbox widgets
        self.current_event_flags = None

    def _get_slot_display_names(self):
        """Get display names for all slots"""
        save_file = self.get_save_file()  # or self.save_file depending on class
        if not save_file:
            return [str(i) for i in range(1, 11)]

        slot_names = []
        profiles = None

        try:
            if save_file.user_data_10_parsed:
                profiles = save_file.user_data_10_parsed.profile_summary.profiles
        except Exception:
            pass

        for i in range(10):
            slot_num = i + 1
            char = save_file.characters[i]

            if char.is_empty():
                slot_names.append(f"{slot_num} - Empty")
                continue

            char_name = "Unknown"
            if profiles and i < len(profiles):
                try:
                    char_name = profiles[i].character_name or "Unknown"
                except Exception:
                    pass

            slot_names.append(f"{slot_num} - {char_name}")

        return slot_names

    def refresh_slot_names(self):
        slot_names = self._get_slot_display_names()

        if hasattr(self, "event_flag_slot_combo"):
            self.event_flag_slot_combo.configure(values=slot_names)
            self.event_flag_slot_combo.set(slot_names[0])

    def setup_ui(self):
        """Setup the event flags tab UI"""
        # Main scrollable container
        main_frame = ctk.CTkScrollableFrame(self.parent, corner_radius=0)
        main_frame.pack(fill=tk.BOTH, expand=True)
        bind_mousewheel(main_frame)

        # Header
        ctk.CTkLabel(
            main_frame,
            text="Event Flags",
            font=("Segoe UI", 18, "bold"),
        ).pack(pady=(15, 5), padx=15, anchor="w")

        ctk.CTkLabel(
            main_frame,
            text="View and edit event flags and respawn bosses",
            font=("Segoe UI", 11),
            text_color=("gray50", "gray70"),
        ).pack(pady=(0, 12), padx=15, anchor="w")

        # Slot selector
        slot_frame = ctk.CTkFrame(main_frame, fg_color="transparent")
        slot_frame.pack(fill=tk.X, padx=15, pady=(0, 10))

        ctk.CTkLabel(slot_frame, text="Character Slot:", font=("Segoe UI", 11)).pack(
            side=tk.LEFT, padx=(0, 8)
        )

        self.eventflag_slot_var = tk.IntVar(value=1)
        slot_names = self._get_slot_display_names()
        self.event_flag_slot_combo = ctk.CTkComboBox(  # Store reference with self.
            slot_frame,
            values=slot_names,
            width=200,
            state="readonly",
            command=lambda v: self.eventflag_slot_var.set(int(v.split(" - ")[0])),
        )
        self.event_flag_slot_combo.set(slot_names[0])
        self.event_flag_slot_combo.pack(side=tk.LEFT, padx=(0, 12))

        ctk.CTkButton(
            slot_frame,
            text="Load Flags",
            command=self.load_event_flags,
            width=130,
        ).pack(side=tk.LEFT, padx=(0, 6))

        ctk.CTkButton(
            slot_frame,
            text="Advanced...",
            command=self.open_advanced_editor,
            width=110,
        ).pack(side=tk.LEFT, padx=(0, 6))

        ctk.CTkButton(
            slot_frame,
            text="Apply Changes",
            command=self.apply_changes,
            width=130,
        ).pack(side=tk.LEFT, padx=(0, 6))

        ctk.CTkButton(
            slot_frame,
            text="Unlock All in Category",
            command=self.unlock_all_in_category,
            width=160,
        ).pack(side=tk.LEFT)

        # Row 2: secondary tools
        tools_row = ctk.CTkFrame(main_frame, fg_color="transparent")
        tools_row.pack(fill=tk.X, padx=15, pady=(6, 20))

        ctk.CTkButton(
            tools_row,
            text="Boss Respawn...",
            command=self.open_boss_respawn,
            width=140,
        ).pack(side=tk.LEFT, padx=(0, 6))

        ctk.CTkButton(
            tools_row,
            text="NPC Revival...",
            command=self.open_npc_revival,
            width=130,
        ).pack(side=tk.LEFT, padx=(0, 6))

        ctk.CTkButton(
            tools_row,
            text="Quest Progress...",
            command=self.open_quest_progress,
            width=145,
        ).pack(side=tk.LEFT, padx=(0, 6))

        ctk.CTkButton(
            tools_row,
            text="Summoning Pools...",
            command=self.open_summoning_pools,
            width=155,
        ).pack(side=tk.LEFT, padx=(0, 6))

        ctk.CTkButton(
            tools_row,
            text="Export Flags...",
            command=self.export_flags,
            width=120,
        ).pack(side=tk.LEFT, padx=(0, 6))

        ctk.CTkButton(
            tools_row,
            text="Import Flags...",
            command=self.import_flags,
            width=120,
        ).pack(side=tk.LEFT)

        # Category selector
        filter_frame = ctk.CTkFrame(main_frame, corner_radius=10)
        filter_frame.pack(fill=tk.X, padx=15, pady=(0, 10))

        ctk.CTkLabel(
            filter_frame,
            text="Browse by Category",
            font=("Segoe UI", 12, "bold"),
        ).pack(pady=(10, 8), padx=12, anchor="w")

        cat_inner = ctk.CTkFrame(filter_frame, fg_color="transparent")
        cat_inner.pack(fill=tk.X, padx=12, pady=(0, 12))

        ctk.CTkLabel(cat_inner, text="Category:").pack(side=tk.LEFT, padx=(0, 8))
        self.category_var = tk.StringVar(value="")
        cat_combo = ctk.CTkComboBox(
            cat_inner,
            variable=self.category_var,
            values=[""] + CATEGORIES,
            state="readonly",
            width=260,
            command=self.on_category_changed,
        )
        cat_combo.pack(side=tk.LEFT, padx=(0, 20))

        ctk.CTkLabel(cat_inner, text="Subcategory:").pack(side=tk.LEFT, padx=(0, 8))
        self.subcategory_var = tk.StringVar(value="")
        self.subcat_combo = ctk.CTkComboBox(
            cat_inner,
            variable=self.subcategory_var,
            state="readonly",
            width=260,
            command=self.on_subcategory_changed,
        )
        self.subcat_combo.pack(side=tk.LEFT)

        # Search bar
        search_frame = ctk.CTkFrame(main_frame, corner_radius=10)
        search_frame.pack(fill=tk.X, padx=15, pady=(0, 10))

        ctk.CTkLabel(
            search_frame,
            text="Search Flags",
            font=("Segoe UI", 12, "bold"),
        ).pack(pady=(10, 8), padx=12, anchor="w")

        search_inner = ctk.CTkFrame(search_frame, fg_color="transparent")
        search_inner.pack(fill=tk.X, padx=12, pady=(0, 12))

        ctk.CTkLabel(search_inner, text="Search:").pack(side=tk.LEFT, padx=(0, 8))
        self.search_var = tk.StringVar(value="")
        self.search_var.trace_add("write", self.on_search_changed)
        search_entry = ctk.CTkEntry(
            search_inner, textvariable=self.search_var, width=320
        )
        search_entry.pack(side=tk.LEFT, padx=(0, 12))

        ctk.CTkLabel(
            search_inner,
            text="(Search by flag ID or name)",
            text_color=("gray50", "gray70"),
        ).pack(side=tk.LEFT, padx=(0, 12))

        ctk.CTkButton(
            search_inner, text="Clear", command=self.clear_search, width=90
        ).pack(side=tk.LEFT)

        # Flags viewer
        flags_frame = ctk.CTkFrame(main_frame, corner_radius=10)
        flags_frame.pack(fill=tk.BOTH, expand=True, padx=15, pady=(0, 15))

        ctk.CTkLabel(
            flags_frame,
            text="Event Flags",
            font=("Segoe UI", 12, "bold"),
        ).pack(pady=(10, 8), padx=12, anchor="w")

        # Scrollable flags list
        self.flags_inner_frame = ctk.CTkScrollableFrame(
            flags_frame, corner_radius=8, fg_color=("#f5f5f5", "#2a2a3e")
        )
        self.flags_inner_frame.pack(fill=tk.BOTH, expand=True, padx=12, pady=(0, 12))
        bind_mousewheel(self.flags_inner_frame)

        # Action buttons area
        action_frame = ctk.CTkFrame(flags_frame, fg_color="transparent")
        action_frame.pack(fill=tk.X, padx=12, pady=(0, 12))

        self.status_label = ctk.CTkLabel(
            action_frame,
            text="Select a category or search for flags",
            text_color=("gray50", "gray70"),
        )
        self.status_label.pack(side=tk.LEFT)

    def load_event_flags(self):
        """Load event flags for selected character"""
        save_file = self.get_save_file()
        if not save_file:
            CTkMessageBox.showwarning(
                "No Save", "Please load a save file first!", parent=self.parent
            )
            return

        slot_idx = int(self.eventflag_slot_var.get()) - 1
        slot = save_file.characters[slot_idx]

        if slot.is_empty():
            CTkMessageBox.showwarning(
                "Empty Slot", f"Slot {slot_idx + 1} is empty!", parent=self.parent
            )
            return

        self.current_slot = slot_idx

        if not hasattr(slot, "event_flags") or not slot.event_flags:
            CTkMessageBox.showerror(
                "Error", "Event flags not available", parent=self.parent
            )
            return

        self.current_event_flags = self._EventFlagAccessor(slot)
        self.flag_states.clear()
        self.flag_widgets.clear()
        for widget in self.flags_inner_frame.winfo_children():
            widget.destroy()

        self.status_label.configure(
            text=f"Loaded Slot {slot_idx + 1}. Select category or search."
        )

        self.show_toast(f"Loaded event flags for Slot {slot_idx + 1}", duration=2500)

    def on_category_changed(self, choice=None):
        """Handle category selection"""
        if self.current_event_flags is None:
            CTkMessageBox.showwarning(
                "Not Loaded", "Please load event flags for a character first!"
            )
            return

        category = self.category_var.get()
        if not category:
            return

        # Update subcategories
        subcats = get_subcategories(category)
        if subcats:
            self.subcat_combo.configure(values=["All"] + subcats, state="readonly")
            self.subcategory_var.set("All")
            self.on_subcategory_changed()
        else:
            self.subcat_combo.configure(values=[], state="disabled")
            self.subcategory_var.set("")
            # Show all flags in category
            self.display_flags(category, None)

    def on_subcategory_changed(self, choice=None):
        """Handle subcategory selection"""
        if self.current_event_flags is None:
            return

        category = self.category_var.get()
        subcategory = self.subcategory_var.get()

        if category and subcategory:
            self.display_flags(category, None if subcategory == "All" else subcategory)

    def display_flags(self, category, subcategory):
        """Display flags for category/subcategory, rendered in chunks to avoid X11 BadAlloc."""
        for widget in self.flags_inner_frame.winfo_children():
            widget.destroy()
        self.flag_widgets.clear()

        flags = get_category_flags(category, subcategory)
        total = len(flags)

        label = f"{category} > {subcategory}" if subcategory else category
        self.status_label.configure(text=f"Loading {total} flags in {label}...")

        self._render_flags_chunk(flags, 0, total, label)

    _RENDER_CHUNK = 25  # flags per batch
    _RENDER_DELAY = 20  # ms between batches - gives X11 time to flush

    def _render_flags_chunk(self, flags, offset, total, label):
        """Render one chunk of flags, then schedule the next batch."""
        chunk = flags[offset : offset + self._RENDER_CHUNK]

        for flag_id in chunk:
            flag_name = get_flag_name(flag_id)
            is_set = self.current_event_flags.get_flag(flag_id)

            if flag_id not in self.flag_states:
                self.flag_states[flag_id] = is_set

            var = tk.BooleanVar(value=is_set)

            checkbox = ctk.CTkCheckBox(
                self.flags_inner_frame,
                text=f"{flag_id}: {flag_name}",
                variable=var,
                command=lambda fid=flag_id, v=var: self.on_flag_toggled(fid, v),
            )
            checkbox.pack(anchor="w", padx=8, pady=2)

            self.flag_widgets[flag_id] = (checkbox, var)

        # Flush pending X11 requests before allocating the next batch
        self.flags_inner_frame.update_idletasks()

        next_offset = offset + self._RENDER_CHUNK
        if next_offset < total:
            self.status_label.configure(
                text=f"Loading {next_offset}/{total} flags in {label}..."
            )
            self.flags_inner_frame.after(
                self._RENDER_DELAY,
                lambda: self._render_flags_chunk(flags, next_offset, total, label),
            )
        else:
            self.status_label.configure(text=f"Showing {total} flags in {label}")

    def on_flag_toggled(self, flag_id, var):
        """Handle flag checkbox toggle"""
        self.flag_states[flag_id] = var.get()

    def on_search_changed(self, *args):
        """Handle search text change"""
        if self.current_event_flags is None:
            return

        query = self.search_var.get().strip().lower()
        if not query:
            return

        # Clear current display
        for widget in self.flags_inner_frame.winfo_children():
            widget.destroy()
        self.flag_widgets.clear()

        # Search through all categories
        results = []
        for category in CATEGORIES:
            subcats = get_subcategories(category)
            if subcats:
                for subcat in subcats:
                    flags = get_category_flags(category, subcat)
                    for flag_id in flags:
                        flag_name = get_flag_name(flag_id)
                        if query in str(flag_id).lower() or query in flag_name.lower():
                            results.append((flag_id, flag_name, category, subcat))
            else:
                flags = get_category_flags(category, None)
                for flag_id in flags:
                    flag_name = get_flag_name(flag_id)
                    if query in str(flag_id).lower() or query in flag_name.lower():
                        results.append((flag_id, flag_name, category, None))

        self.status_label.configure(text="Searching...")
        self._render_search_chunk(results, 0)

    def _render_search_chunk(self, results, offset):
        """Render one chunk of search results, then schedule the next batch."""
        chunk = results[offset : offset + self._RENDER_CHUNK]

        for flag_id, flag_name, category, subcategory in chunk:
            is_set = self.current_event_flags.get_flag(flag_id)

            if flag_id not in self.flag_states:
                self.flag_states[flag_id] = is_set

            var = tk.BooleanVar(value=is_set)

            location = f"{category} > {subcategory}" if subcategory else category

            checkbox = ctk.CTkCheckBox(
                self.flags_inner_frame,
                text=f"{flag_id}: {flag_name} ({location})",
                variable=var,
                command=lambda fid=flag_id, v=var: self.on_flag_toggled(fid, v),
            )
            checkbox.pack(anchor="w", padx=8, pady=2)

            self.flag_widgets[flag_id] = (checkbox, var)

        self.flags_inner_frame.update_idletasks()

        next_offset = offset + self._RENDER_CHUNK
        total = len(results)
        if next_offset < total:
            self.flags_inner_frame.after(
                self._RENDER_DELAY,
                lambda: self._render_search_chunk(results, next_offset),
            )
        else:
            self.status_label.configure(text=f"Found {total} matching flags")

    def clear_search(self):
        """Clear search field"""
        self.search_var.set("")
        for widget in self.flags_inner_frame.winfo_children():
            widget.destroy()
        self.flag_widgets.clear()
        self.status_label.configure(text="Select a category or search for flags")

    def unlock_all_in_category(self):
        """Unlock all flags in current category"""
        if not self.flag_widgets:
            CTkMessageBox.showwarning(
                "No Flags", "No flags are currently displayed!", parent=self.parent
            )
            return

        result = CTkMessageBox.askyesno(
            "Confirm",
            f"Set all {len(self.flag_widgets)} displayed flags to ON?\n\n"
            f"This will affect only the flags currently visible.",
            parent=self.parent,
        )

        if result:
            for flag_id, (checkbox, var) in self.flag_widgets.items():
                var.set(True)
                self.flag_states[flag_id] = True
                checkbox.select()

            CTkMessageBox.showinfo(
                "Success",
                f"Enabled all {len(self.flag_widgets)} displayed flags.\n\nClick 'Apply Changes' to save.",
                parent=self.parent,
            )

    def apply_changes(self):
        """Apply flag changes to save file"""
        if self.current_event_flags is None:
            CTkMessageBox.showwarning(
                "Not Loaded", "No event flags loaded!", parent=self.parent
            )
            return

        if not self.flag_states:
            CTkMessageBox.showwarning(
                "No Changes", "No flags have been modified!", parent=self.parent
            )
            return

        # Count changes
        changes = 0
        for flag_id, new_state in self.flag_states.items():
            current_state = self.current_event_flags.get_flag(flag_id)
            if current_state != new_state:
                changes += 1

        if changes == 0:
            CTkMessageBox.showinfo(
                "No Changes", "No flags were modified!", parent=self.parent
            )
            return

        result = CTkMessageBox.askyesno(
            "Confirm Changes",
            f"Apply {changes} flag changes to Slot {self.current_slot + 1}?\n\n"
            f"A backup will be created automatically.",
            parent=self.parent,
        )

        if not result:
            return

        # Get save file for backup
        save_file = self.get_save_file()

        # Create backup
        save_path = self.get_save_path()
        if save_path:
            backup_mgr = BackupManager(save_path)
            backup_mgr.create_backup(
                description=f"Before event flag changes (Slot {self.current_slot + 1})",
                operation="event_flag_changes",
                save=save_file,
            )

        # Apply changes
        for flag_id, new_state in self.flag_states.items():
            self.current_event_flags.set_flag(flag_id, new_state)

        # CRITICAL: Write the modified event_flags buffer back to _raw_data
        # The set_flag() updates slot.event_flags in memory, but we must also
        # update the save file's raw data buffer that gets written to disk
        slot = save_file.character_slots[self.current_slot]

        if hasattr(slot, "event_flags_offset") and slot.event_flags_offset > 0:
            # Calculate absolute offset in the raw data
            absolute_offset = slot.event_flags_offset
            event_flags_size = 0x1BF99F  # 1,833,375 bytes

            # Write the modified event_flags buffer to raw_data
            save_file._raw_data[
                absolute_offset : absolute_offset + event_flags_size
            ] = slot.event_flags

        # Recalculate checksums before saving
        save_file.recalculate_checksums()

        # Save
        save_file.save(self.get_save_path())
        self.reload_save()
        self.show_toast(
            f"Applied {changes} flag changes to Slot {self.current_slot + 1}!",
            duration=2500,
        )

        # Clear states
        self.flag_states.clear()

    def export_flags(self):
        """Export all set event flags to a JSON file."""
        if self.current_event_flags is None:
            CTkMessageBox.showwarning(
                "Not Loaded", "Please load event flags for a character first!"
            )
            return

        import json
        from tkinter import filedialog

        save_path = self.get_save_path()
        initial_dir = str(save_path.parent) if save_path else None
        slot_num = (self.current_slot + 1) if self.current_slot is not None else 1

        out_path = filedialog.asksaveasfilename(
            parent=self.parent,
            title="Export Event Flags",
            initialdir=initial_dir,
            initialfile=f"flags_slot{slot_num}.json",
            defaultextension=".json",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
        )
        if not out_path:
            return

        try:
            set_flags = []
            seen: set[int] = set()

            for category in CATEGORIES:
                subcats = get_subcategories(category)
                if subcats:
                    for subcat in subcats:
                        for flag_id in get_category_flags(category, subcat):
                            if flag_id in seen:
                                continue
                            seen.add(flag_id)
                            try:
                                if self.current_event_flags.get_flag(flag_id):
                                    set_flags.append(
                                        {
                                            "id": flag_id,
                                            "name": get_flag_name(flag_id),
                                        }
                                    )
                            except Exception:
                                pass
                else:
                    for flag_id in get_category_flags(category, None):
                        if flag_id in seen:
                            continue
                        seen.add(flag_id)
                        try:
                            if self.current_event_flags.get_flag(flag_id):
                                set_flags.append(
                                    {
                                        "id": flag_id,
                                        "name": get_flag_name(flag_id),
                                    }
                                )
                        except Exception:
                            pass

            data = {
                "slot": slot_num,
                "count": len(set_flags),
                "flags": set_flags,
            }
            with open(out_path, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2)

            self.show_toast(f"Exported {len(set_flags)} set flags", duration=2500)

        except Exception as e:
            CTkMessageBox.showerror(
                "Export Failed", f"Could not export flags:\n{e}", parent=self.parent
            )

    def import_flags(self):
        """Apply flags from a JSON file. Entries with "state": false are cleared; others are set.
        Backward compatible: entries without a "state" field default to true."""
        if self.current_event_flags is None:
            CTkMessageBox.showwarning(
                "Not Loaded", "Please load event flags for a character first!"
            )
            return

        import json
        from tkinter import filedialog

        save_path = self.get_save_path()
        initial_dir = str(save_path.parent) if save_path else None

        in_path = filedialog.askopenfilename(
            parent=self.parent,
            title="Import Event Flags",
            initialdir=initial_dir,
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
        )
        if not in_path:
            return

        try:
            with open(in_path, encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:
            CTkMessageBox.showerror(
                "Import Failed", f"Could not read file:\n{e}", parent=self.parent
            )
            return

        if "flags" not in data or not isinstance(data["flags"], list):
            CTkMessageBox.showerror(
                "Invalid File",
                "File does not contain a valid flags list.",
                parent=self.parent,
            )
            return

        # Parse (flag_id, state) pairs; "state" defaults to True for plain exports
        flag_ops: list[tuple[int, bool]] = []
        for entry in data["flags"]:
            if isinstance(entry, dict) and "id" in entry:
                try:
                    state = bool(entry.get("state", True))
                    flag_ops.append((int(entry["id"]), state))
                except (ValueError, TypeError):
                    pass

        if not flag_ops:
            CTkMessageBox.showinfo(
                "Nothing to Import",
                "No valid flag IDs found in file.",
                parent=self.parent,
            )
            return

        set_count = sum(1 for _, s in flag_ops if s)
        unset_count = len(flag_ops) - set_count
        summary = f"Set {set_count}" + (f", unset {unset_count}" if unset_count else "")
        result = CTkMessageBox.askyesno(
            "Confirm Import",
            f"{summary} flags on Slot {self.current_slot + 1}?",
            parent=self.parent,
        )
        if not result:
            return

        save_file = self.get_save_file()

        try:
            backup_mgr = BackupManager(save_path)
            backup_mgr.create_backup(
                description=f"Before flag import (Slot {self.current_slot + 1})",
                operation="flag_import",
                save=save_file,
            )
        except PermissionError:
            CTkMessageBox.showwarning(
                "Backup Skipped",
                "Could not create backup (permission denied). Proceeding.",
                parent=self.parent,
            )

        applied = 0
        for flag_id, state in flag_ops:
            try:
                self.current_event_flags.set_flag(flag_id, state)
                applied += 1
            except Exception:
                pass

        slot = save_file.character_slots[self.current_slot]
        if hasattr(slot, "event_flags_offset") and slot.event_flags_offset > 0:
            absolute_offset = slot.event_flags_offset
            event_flags_size = 0x1BF99F
            save_file._raw_data[
                absolute_offset : absolute_offset + event_flags_size
            ] = slot.event_flags

        save_file.recalculate_checksums()
        save_file.save(self.get_save_path())
        self.reload_save()

        # Refresh displayed checkboxes to reflect imported state
        if self.flag_widgets:
            for flag_id, (_cb, var) in self.flag_widgets.items():
                current = self.current_event_flags.get_flag(flag_id)
                var.set(current)
                self.flag_states[flag_id] = current

        self.show_toast(f"Imported {applied} flags", duration=2500)

    def open_advanced_editor(self):
        """Open advanced flag editor dialog"""
        if self.current_event_flags is None:
            CTkMessageBox.showwarning(
                "Not Loaded", "Please load event flags for a character first!"
            )
            return

        from er_save_manager.ui.utils import force_render_dialog

        dialog = ctk.CTkToplevel(self.parent)
        dialog.title("Advanced Event Flag Editor")
        width, height = 600, 500
        dialog.transient(self.parent)

        # Center dialog over parent window
        dialog.update_idletasks()
        self.parent.update_idletasks()
        parent_x = self.parent.winfo_rootx()
        parent_y = self.parent.winfo_rooty()
        parent_width = self.parent.winfo_width()
        parent_height = self.parent.winfo_height()
        x = parent_x + (parent_width // 2) - (width // 2)
        y = parent_y + (parent_height // 2) - (height // 2)
        dialog.geometry(f"{width}x{height}+{x}+{y}")

        # Force rendering on Linux before grab_set
        force_render_dialog(dialog)
        dialog.grab_set()

        ctk.CTkLabel(
            dialog,
            text="Advanced Event Flag Editor",
            font=("Segoe UI", 14, "bold"),
        ).pack(pady=(15, 10), padx=15)

        # Input frame
        input_frame = ctk.CTkFrame(dialog, fg_color="transparent")
        input_frame.pack(fill=tk.X, padx=15, pady=10)

        ctk.CTkLabel(input_frame, text="Flag ID:").pack(side=tk.LEFT, padx=(0, 8))

        flag_id_var = tk.StringVar(value="")
        flag_entry = ctk.CTkEntry(input_frame, textvariable=flag_id_var, width=150)
        flag_entry.pack(side=tk.LEFT, padx=(0, 12))

        def toggle_flag():
            try:
                flag_id = int(flag_id_var.get())
            except ValueError:
                CTkMessageBox.showerror("Error", "Invalid flag ID!", parent=dialog)
                return

            try:
                save_file = self.get_save_file()
                save_path = self.get_save_path()

                if not save_path or not save_path.is_file():
                    CTkMessageBox.showerror(
                        "Invalid Save Path",
                        "Could not locate save file.",
                        parent=dialog,
                    )
                    return

                try:
                    backup_mgr = BackupManager(save_path)
                    backup_mgr.create_backup(
                        description=f"Before advanced flag toggle {flag_id} (Slot {self.current_slot + 1})",
                        operation="advanced_flag_toggle",
                        save=save_file,
                    )
                except PermissionError:
                    CTkMessageBox.showwarning(
                        "Backup Skipped",
                        "Could not create backup (permission denied). Proceeding.",
                        parent=dialog,
                    )

                current = self.current_event_flags.get_flag(flag_id)
                new_state = not current
                self.current_event_flags.set_flag(flag_id, new_state)

                slot = save_file.character_slots[self.current_slot]
                if hasattr(slot, "event_flags_offset") and slot.event_flags_offset > 0:
                    absolute_offset = slot.event_flags_offset
                    event_flags_size = 0x1BF99F
                    save_file._raw_data[
                        absolute_offset : absolute_offset + event_flags_size
                    ] = slot.event_flags

                save_file.recalculate_checksums()
                save_file.save(save_path)
                self.reload_save()

                self.show_toast(
                    f"Flag {flag_id} set to {'ON' if new_state else 'OFF'}",
                    duration=2000,
                )
            except Exception as e:
                CTkMessageBox.showerror(
                    "Error", f"Failed to toggle flag: {e}", parent=dialog
                )

        def check_flag():
            try:
                flag_id = int(flag_id_var.get())
                state = self.current_event_flags.get_flag(flag_id)
                flag_name = get_flag_name(flag_id)
                CTkMessageBox.showinfo(
                    "Flag Status",
                    f"Flag {flag_id}: {flag_name}\n\nState: {'ON' if state else 'OFF'}",
                    parent=dialog,
                )
            except ValueError:
                CTkMessageBox.showerror("Error", "Invalid flag ID!", parent=dialog)
            except Exception as e:
                CTkMessageBox.showerror(
                    "Error", f"Failed to check flag: {e}", parent=dialog
                )

        ctk.CTkButton(input_frame, text="Toggle", command=toggle_flag, width=100).pack(
            side=tk.LEFT, padx=2
        )

        ctk.CTkButton(input_frame, text="Check", command=check_flag, width=100).pack(
            side=tk.LEFT, padx=2
        )

        # Help text
        help_frame = ctk.CTkFrame(dialog, corner_radius=10)
        help_frame.pack(fill=tk.BOTH, expand=True, padx=15, pady=(0, 15))

        help_text = tk.Text(
            help_frame,
            wrap=tk.WORD,
            font=("Segoe UI", 10),
            padx=12,
            pady=12,
            bg="#1f1f28",
            fg="#e5e5f5",
            relief=tk.FLAT,
            highlightthickness=0,
        )
        help_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        help_text.insert(
            "1.0",
            "Advanced Flag Editor\n\n"
            "Use this to directly toggle or check individual flags by ID.\n\n"
            "How to use:\n"
            "1. Enter a flag ID (e.g., 1035, 10000800)\n"
            "2. Click 'Check' to see current state\n"
            "3. Click 'Toggle' to flip the flag on/off\n\n"
            "Warning:\n"
            "- Changing unknown flags may break your save\n"
            "- Always backup before experimenting\n"
            "- Use the category browser for documented flags\n\n"
            "Tip: You can find flag IDs in the event_flags_db.py file in the source code.",
        )
        help_text.configure(state="disabled")

        ctk.CTkButton(dialog, text="Close", command=dialog.destroy, width=120).pack(
            pady=(0, 15)
        )

    def open_boss_respawn(self):
        """Open boss respawn dialog"""
        if self.current_event_flags is None:
            CTkMessageBox.showwarning(
                "Not Loaded", "Please load event flags for a character first!"
            )
            return

        from er_save_manager.ui.utils import force_render_dialog

        dialog = ctk.CTkToplevel(self.parent)
        dialog.title("Boss Respawn")
        width, height = 700, 600
        dialog.transient(self.parent)
        dialog.update_idletasks()
        # Center over parent window
        self.parent.update_idletasks()
        parent_x = self.parent.winfo_rootx()
        parent_y = self.parent.winfo_rooty()
        parent_width = self.parent.winfo_width()
        parent_height = self.parent.winfo_height()
        x = parent_x + (parent_width // 2) - (width // 2)
        y = parent_y + (parent_height // 2) - (height // 2)
        dialog.geometry(f"{width}x{height}+{x}+{y}")
        # Force rendering on Linux before grab_set
        force_render_dialog(dialog)
        dialog.grab_set()

        ctk.CTkLabel(
            dialog,
            text="Boss Respawn",
            font=("Segoe UI", 14, "bold"),
        ).pack(pady=(15, 5), padx=15)

        ctk.CTkLabel(
            dialog,
            text="Reset boss defeat flags to respawn bosses",
            text_color=("gray50", "gray70"),
        ).pack(pady=(0, 12), padx=15)

        # Category selector
        cat_frame = ctk.CTkFrame(dialog, fg_color="transparent")
        cat_frame.pack(fill=tk.X, padx=15, pady=(0, 10))

        ctk.CTkLabel(cat_frame, text="Boss Category:").pack(side=tk.LEFT, padx=(0, 8))

        boss_category_var = tk.StringVar(value=BOSS_CATEGORIES[0])
        cat_combo = ctk.CTkComboBox(
            cat_frame,
            variable=boss_category_var,
            values=BOSS_CATEGORIES,
            state="readonly",
            width=300,
        )
        cat_combo.pack(side=tk.LEFT)

        # Boss list
        boss_frame = ctk.CTkScrollableFrame(dialog, corner_radius=10)
        boss_frame.pack(fill=tk.BOTH, expand=True, padx=15, pady=(0, 10))
        bind_mousewheel(boss_frame)

        boss_vars = {}

        def populate_bosses(*_args):
            # Clear current bosses
            for widget in boss_frame.winfo_children():
                widget.destroy()
            boss_vars.clear()

            category = boss_category_var.get()
            bosses_in_cat = get_bosses_by_category(category)

            for boss_name in bosses_in_cat:
                flags = get_boss_flags(boss_name)
                if not flags:
                    continue

                is_defeated = any(
                    self.current_event_flags.get_flag(fid) for fid in flags
                )
                var = tk.BooleanVar(value=False)
                boss_vars[boss_name] = (flags, var)

                item_frame = ctk.CTkFrame(
                    boss_frame,
                    corner_radius=6,
                    fg_color=("#ffffff", "#1f1f28"),
                )
                item_frame.pack(fill=tk.X, pady=3, padx=4)

                status = "Defeated" if is_defeated else "Alive"
                checkbox = ctk.CTkCheckBox(
                    item_frame,
                    text=f"{boss_name} ({status})",
                    variable=var,
                )
                checkbox.pack(side=tk.LEFT, padx=8, pady=6)

        cat_combo.configure(command=populate_bosses)
        populate_bosses()

        # Action buttons
        btn_frame = ctk.CTkFrame(dialog, fg_color="transparent")
        btn_frame.pack(fill=tk.X, padx=15, pady=(0, 15))

        def respawn_selected():
            """Respawn selected bosses"""
            save_path = self.get_save_path()
            if not save_path or not save_path.is_file():
                CTkMessageBox.showerror(
                    "Invalid Save Path",
                    "Could not locate the save file to back up. Load a valid save (.sl2) first.",
                )
                return

            count = 0
            for _boss_name, (flags, var) in boss_vars.items():
                if var.get():  # user explicitly selected this boss
                    is_defeated_now = any(
                        self.current_event_flags.get_flag(fid) for fid in flags
                    )
                    if is_defeated_now:
                        for flag_id in flags:
                            self.current_event_flags.set_flag(flag_id, False)
                        count += 1

            if count == 0:
                CTkMessageBox.showinfo(
                    "No Selection",
                    "No valid selections. Select defeated bosses to respawn.",
                    parent=dialog,
                )
                return

            # Get save file for backup
            save_file = self.get_save_file()

            if save_path and save_path.is_file():
                try:
                    backup_mgr = BackupManager(save_path)
                    backup_mgr.create_backup(
                        description=f"Before boss respawn (Slot {self.current_slot + 1})",
                        operation="respawn_boss",
                        save=save_file,
                    )
                except PermissionError:
                    CTkMessageBox.showwarning(
                        "Backup Skipped",
                        "Could not create backup (permission denied)."
                        " Continuing without backup.",
                    )
            else:
                CTkMessageBox.showwarning(
                    "Backup Skipped",
                    "Could not create backup because the save path is not a file."
                    " Proceeding without backup.",
                )

            # Write to raw data and recalculate checksums
            slot = save_file.character_slots[self.current_slot]

            if hasattr(slot, "event_flags_offset") and slot.event_flags_offset > 0:
                absolute_offset = slot.event_flags_offset
                event_flags_size = 0x1BF99F
                save_file._raw_data[
                    absolute_offset : absolute_offset + event_flags_size
                ] = slot.event_flags

            save_file.recalculate_checksums()
            save_file.save(self.get_save_path())
            self.reload_save()

            # Teleport to Roundtable Hold
            try:
                from er_save_manager.fixes.teleport import TeleportFix

                teleport = TeleportFix("roundtable")
                result = teleport.apply(save_file, self.current_slot)
                if result.applied:
                    save_file.recalculate_checksums()
                    save_file.save(self.get_save_path())
                    self.reload_save()
            except Exception as e:
                CTkMessageBox.showwarning(
                    "Teleport Failed",
                    f"Could not teleport to Roundtable Hold: {e}",
                    parent=dialog,
                )

            self.show_toast("Boss respawned successfully!", duration=2500)
            dialog.destroy()

        def respawn_all():
            """Respawn all bosses in category"""
            save_path = self.get_save_path()
            if not save_path or not save_path.is_file():
                CTkMessageBox.showerror(
                    "Invalid Save Path",
                    "Could not locate the save file to back up. Load a valid save (.sl2) first.",
                    parent=dialog,
                )
                return

            result = CTkMessageBox.askyesno(
                "Confirm",
                f"Respawn ALL bosses in {boss_category_var.get()}?\n\n"
                f"This will reset {len(boss_vars)} boss(es).",
                parent=dialog,
            )

            if not result:
                return

            count = 0
            for _boss_name, (flags, _var) in boss_vars.items():
                for flag_id in flags:
                    self.current_event_flags.set_flag(flag_id, False)
                count += 1

            # Get save file for backup
            save_file = self.get_save_file()

            # Create backup
            save_path = self.get_save_path()
            if save_path and save_path.is_file():
                try:
                    backup_mgr = BackupManager(save_path)
                    backup_mgr.create_backup(
                        description=f"Before respawn all ({boss_category_var.get()}, Slot {self.current_slot + 1})",
                        operation="respawn_all_bosses",
                        save=save_file,
                    )
                except PermissionError:
                    CTkMessageBox.showwarning(
                        "Backup Skipped",
                        "Could not create backup (permission denied)."
                        " Continuing without backup.",
                        parent=dialog,
                    )
            else:
                CTkMessageBox.showwarning(
                    "Backup Skipped",
                    "Could not create backup because the save path is not a file."
                    " Proceeding without backup.",
                    parent=dialog,
                )

            # Write to raw data and recalculate checksums
            slot = save_file.character_slots[self.current_slot]

            if hasattr(slot, "event_flags_offset") and slot.event_flags_offset > 0:
                absolute_offset = slot.event_flags_offset
                event_flags_size = 0x1BF99F
                save_file._raw_data[
                    absolute_offset : absolute_offset + event_flags_size
                ] = slot.event_flags

            save_file.recalculate_checksums()
            save_file.save(self.get_save_path())
            self.reload_save()

            # Teleport to Roundtable Hold
            try:
                from er_save_manager.fixes.teleport import TeleportFix

                teleport = TeleportFix("roundtable")
                result = teleport.apply(save_file, self.current_slot)
                if result.applied:
                    save_file.recalculate_checksums()
                    save_file.save(self.get_save_path())
                    self.reload_save()
            except Exception as e:
                CTkMessageBox.showwarning(
                    "Teleport Failed",
                    f"Could not teleport to Roundtable Hold: {e}",
                    parent=dialog,
                )

            self.show_toast(
                f"Respawned all {count} bosses in {boss_category_var.get()}!",
                duration=2500,
            )
            dialog.destroy()

        ctk.CTkButton(btn_frame, text="Close", command=dialog.destroy, width=120).pack(
            side=tk.LEFT
        )

        ctk.CTkButton(
            btn_frame, text="Respawn Selected", command=respawn_selected, width=150
        ).pack(side=tk.RIGHT, padx=(0, 8))

        ctk.CTkButton(
            btn_frame, text="Respawn All in Category", command=respawn_all, width=180
        ).pack(side=tk.RIGHT)

    def open_npc_revival(self):
        """Open NPC revival dialog"""
        if self.current_event_flags is None:
            CTkMessageBox.showwarning(
                "Not Loaded", "Please load event flags for a character first!"
            )
            return

        from er_save_manager.data.npc_data import NPC_FLAGS, get_npc_state, revive_npc
        from er_save_manager.ui.utils import force_render_dialog

        dialog = ctk.CTkToplevel(self.parent)
        dialog.title("NPC Revival")
        width, height = 700, 600
        dialog.transient(self.parent)
        dialog.update_idletasks()

        # Center dialog
        self.parent.update_idletasks()
        parent_x = self.parent.winfo_rootx()
        parent_y = self.parent.winfo_rooty()
        parent_width = self.parent.winfo_width()
        parent_height = self.parent.winfo_height()
        x = parent_x + (parent_width // 2) - (width // 2)
        y = parent_y + (parent_height // 2) - (height // 2)
        dialog.geometry(f"{width}x{height}+{x}+{y}")

        force_render_dialog(dialog)
        dialog.grab_set()

        ctk.CTkLabel(
            dialog,
            text="NPC Revival",
            font=("Segoe UI", 14, "bold"),
        ).pack(pady=(15, 5), padx=15)

        ctk.CTkLabel(
            dialog,
            text="Revive dead NPCs (does not restore quest progress)",
            text_color=("gray50", "gray70"),
        ).pack(pady=(0, 12), padx=15)

        # NPC list
        npc_frame = ctk.CTkScrollableFrame(dialog, corner_radius=10)
        npc_frame.pack(fill=tk.BOTH, expand=True, padx=15, pady=(0, 10))
        bind_mousewheel(npc_frame)

        npc_vars = {}

        for npc_name, (_base_flag, location) in sorted(NPC_FLAGS.items()):
            state = get_npc_state(self.current_event_flags, npc_name)
            if not state:
                continue

            is_dead = state["dead"]
            is_aggro = state["aggro_absolvable"] or state["aggro_permanent"]

            status = "Dead" if is_dead else ("Hostile" if is_aggro else "Alive")

            var = tk.BooleanVar(value=False)
            npc_vars[npc_name] = var

            item_frame = ctk.CTkFrame(
                npc_frame,
                corner_radius=6,
                fg_color=("#ffffff", "#1f1f28"),
            )
            item_frame.pack(fill=tk.X, pady=3, padx=4)

            checkbox = ctk.CTkCheckBox(
                item_frame,
                text=f"{npc_name} ({status}) - {location}",
                variable=var,
            )
            checkbox.pack(side=tk.LEFT, padx=8, pady=6)

        # Action buttons
        btn_frame = ctk.CTkFrame(dialog, fg_color="transparent")
        btn_frame.pack(fill=tk.X, padx=15, pady=(0, 15))

        def revive_selected():
            """Revive selected NPCs"""
            save_path = self.get_save_path()
            if not save_path or not save_path.is_file():
                CTkMessageBox.showerror(
                    "Invalid Save Path",
                    "Could not locate save file. Load a valid save first.",
                    parent=dialog,
                )
                return

            count = 0
            for npc_name, var in npc_vars.items():
                if var.get():
                    if revive_npc(self.current_event_flags, npc_name):
                        count += 1

            if count == 0:
                CTkMessageBox.showinfo(
                    "No Selection",
                    "No NPCs selected for revival.",
                    parent=dialog,
                )
                return

            # Create backup
            save_file = self.get_save_file()
            if save_path:
                try:
                    backup_mgr = BackupManager(save_path)
                    backup_mgr.create_backup(
                        description=f"Before NPC revival (Slot {self.current_slot + 1})",
                        operation="npc_revival",
                        save=save_file,
                    )
                except PermissionError:
                    CTkMessageBox.showwarning(
                        "Backup Skipped",
                        "Could not create backup (permission denied).",
                        parent=dialog,
                    )

            # Write to raw data and save
            slot = save_file.character_slots[self.current_slot]
            if hasattr(slot, "event_flags_offset") and slot.event_flags_offset > 0:
                absolute_offset = slot.event_flags_offset
                event_flags_size = 0x1BF99F
                save_file._raw_data[
                    absolute_offset : absolute_offset + event_flags_size
                ] = slot.event_flags

            save_file.recalculate_checksums()
            save_file.save(self.get_save_path())
            self.reload_save()

            self.show_toast(f"Revived {count} NPC(s)!", duration=2500)
            dialog.destroy()

        ctk.CTkButton(btn_frame, text="Close", command=dialog.destroy, width=120).pack(
            side=tk.LEFT
        )

        ctk.CTkButton(
            btn_frame, text="Revive Selected", command=revive_selected, width=150
        ).pack(side=tk.RIGHT)

    def open_quest_progress(self):
        if self.current_event_flags is None:
            CTkMessageBox.showwarning(
                "Not Loaded", "Please load event flags for a character first!"
            )
            return

        from er_save_manager.ui.quest_progress_dialog import QuestProgressDialog

        QuestProgressDialog.open(
            self.parent,
            self.current_event_flags,
            self.get_save_file(),
            self.get_save_path(),
            self.current_slot,
            self.reload_save,
            self.show_toast,
        )

    def open_summoning_pools(self):
        """Open the summoning pool enable/disable dialog."""
        if self.current_event_flags is None:
            CTkMessageBox.showwarning(
                "Not Loaded", "Please load event flags for a character first!"
            )
            return

        from er_save_manager.ui.utils import force_render_dialog

        dialog = ctk.CTkToplevel(self.parent)
        dialog.title("Summoning Pools")
        width, height = 720, 640
        dialog.transient(self.parent)
        dialog.update_idletasks()

        self.parent.update_idletasks()
        parent_x = self.parent.winfo_rootx()
        parent_y = self.parent.winfo_rooty()
        parent_width = self.parent.winfo_width()
        parent_height = self.parent.winfo_height()
        x = parent_x + (parent_width // 2) - (width // 2)
        y = parent_y + (parent_height // 2) - (height // 2)
        dialog.geometry(f"{width}x{height}+{x}+{y}")

        force_render_dialog(dialog)
        dialog.grab_set()

        ctk.CTkLabel(
            dialog,
            text="Summoning Pools",
            font=("Segoe UI", 14, "bold"),
        ).pack(pady=(15, 2), padx=15)

        ctk.CTkLabel(
            dialog,
            text="Enable or disable summoning pool activation flags",
            text_color=("gray50", "gray70"),
        ).pack(pady=(0, 10), padx=15)

        # Selection toolbar
        sel_frame = ctk.CTkFrame(dialog, fg_color="transparent")
        sel_frame.pack(fill=tk.X, padx=15, pady=(0, 8))

        # Checkbox vars: {flag_id: BooleanVar} - True means selected for action
        pool_vars: dict[int, tk.BooleanVar] = {}

        all_flags = [
            (flag_id, label, "base") for flag_id, label in SUMMONING_POOL_FLAGS_BASE
        ] + [(flag_id, label, "dlc") for flag_id, label in SUMMONING_POOL_FLAGS_DLC]

        def select_group(group: str) -> None:
            for flag_id, _label, g in all_flags:
                if g == group:
                    pool_vars[flag_id].set(True)

        def select_all() -> None:
            for var in pool_vars.values():
                var.set(True)

        def unselect_all() -> None:
            for var in pool_vars.values():
                var.set(False)

        ctk.CTkButton(
            sel_frame,
            text="Select Base",
            command=lambda: select_group("base"),
            width=110,
        ).pack(side=tk.LEFT, padx=(0, 6))

        ctk.CTkButton(
            sel_frame, text="Select DLC", command=lambda: select_group("dlc"), width=110
        ).pack(side=tk.LEFT, padx=(0, 6))

        ctk.CTkButton(sel_frame, text="Select All", command=select_all, width=100).pack(
            side=tk.LEFT, padx=(0, 6)
        )

        ctk.CTkButton(
            sel_frame, text="Unselect All", command=unselect_all, width=110
        ).pack(side=tk.LEFT)

        # Scrollable pool list
        pool_frame = ctk.CTkScrollableFrame(dialog, corner_radius=10)
        pool_frame.pack(fill=tk.BOTH, expand=True, padx=15, pady=(0, 10))
        bind_mousewheel(pool_frame)

        def _make_section_header(parent, text: str) -> None:
            ctk.CTkLabel(
                parent,
                text=text,
                font=("Segoe UI", 11, "bold"),
                text_color=("gray30", "gray80"),
            ).pack(anchor="w", padx=8, pady=(10, 4))

        _make_section_header(pool_frame, "Base Game")

        for flag_id, label in SUMMONING_POOL_FLAGS_BASE:
            is_active = self.current_event_flags.get_flag(flag_id)
            status = "Active" if is_active else "Inactive"
            var = tk.BooleanVar(value=False)
            pool_vars[flag_id] = var
            ctk.CTkCheckBox(
                pool_frame,
                text=f"{flag_id}: {label}  ({status})",
                variable=var,
            ).pack(anchor="w", padx=8, pady=2)

        _make_section_header(pool_frame, "Shadow of the Erdtree (DLC)")

        for flag_id, label in SUMMONING_POOL_FLAGS_DLC:
            is_active = self.current_event_flags.get_flag(flag_id)
            status = "Active" if is_active else "Inactive"
            var = tk.BooleanVar(value=False)
            pool_vars[flag_id] = var
            ctk.CTkCheckBox(
                pool_frame,
                text=f"{flag_id}: {label}  ({status})",
                variable=var,
            ).pack(anchor="w", pady=2, padx=8)

        # Action buttons
        btn_frame = ctk.CTkFrame(dialog, fg_color="transparent")
        btn_frame.pack(fill=tk.X, padx=15, pady=(0, 15))

        def _apply(state: bool) -> None:
            selected = [fid for fid, var in pool_vars.items() if var.get()]
            if not selected:
                CTkMessageBox.showinfo(
                    "No Selection", "No pools selected.", parent=dialog
                )
                return

            action = "Enable" if state else "Disable"
            result = CTkMessageBox.askyesno(
                "Confirm",
                f"{action} {len(selected)} summoning pool flags on Slot {self.current_slot + 1}?\n\n"
                "A backup will be created automatically.",
                parent=dialog,
            )
            if not result:
                return

            save_file = self.get_save_file()
            save_path = self.get_save_path()

            if save_path and save_path.is_file():
                try:
                    backup_mgr = BackupManager(save_path)
                    backup_mgr.create_backup(
                        description=f"Before summoning pool {action.lower()} (Slot {self.current_slot + 1})",
                        operation="summoning_pools",
                        save=save_file,
                    )
                except PermissionError:
                    CTkMessageBox.showwarning(
                        "Backup Skipped",
                        "Could not create backup (permission denied). Continuing without backup.",
                        parent=dialog,
                    )

            for flag_id in selected:
                self.current_event_flags.set_flag(flag_id, state)

            slot = save_file.character_slots[self.current_slot]
            if hasattr(slot, "event_flags_offset") and slot.event_flags_offset > 0:
                absolute_offset = slot.event_flags_offset
                event_flags_size = 0x1BF99F
                save_file._raw_data[
                    absolute_offset : absolute_offset + event_flags_size
                ] = slot.event_flags

            save_file.recalculate_checksums()
            save_file.save(self.get_save_path())
            self.reload_save()

            self.show_toast(
                f"{action}d {len(selected)} summoning pool flags on Slot {self.current_slot + 1}",
                duration=2500,
            )
            dialog.destroy()

        ctk.CTkButton(btn_frame, text="Close", command=dialog.destroy, width=120).pack(
            side=tk.LEFT
        )

        ctk.CTkButton(
            btn_frame,
            text="Disable Selected",
            command=lambda: _apply(False),
            width=150,
        ).pack(side=tk.RIGHT, padx=(8, 0))

        ctk.CTkButton(
            btn_frame,
            text="Enable Selected",
            command=lambda: _apply(True),
            width=150,
        ).pack(side=tk.RIGHT)
